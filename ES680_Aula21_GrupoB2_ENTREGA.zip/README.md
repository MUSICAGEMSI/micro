# ES680 — Aula 21, Grupo B2

Implementação em `Aula_21_Grupo_B2/`, feita sobre cópia da Aula 18 v1.1 do
pacote V2. O projeto original do GitHub em `Aula_20/` permanece intacto.

Cinco botões externos (PC1–4, PB0), debounce compartilhado TIM7 de 10ms,
eventos de 500ms e 3s por TIM16, coexistência com TIM6/teclado matricial.
Cima/Baixo alteram contador de quatro LEDs; Enter 3s zera. Modo 21 impede
que a demonstração antiga escreva nos mesmos LEDs.

Compilado com GNU ARM 14.2.1; 59 cenários lógicos aprovados com HAL mínima
e sanitizadores. **CubeMX/CubeIDE e placa física ainda não validados.**
O `.ioc` e os arquivos de hardware foram preparados manualmente; a
regeneração e o teste físico devem seguir as pendências documentadas.

## Compilar pela linha de comando

Requisitos: Python 3 e GNU Arm Embedded GCC/newlib-nano no PATH. Neste
ambiente, antes do build:

```bash
export PATH="/workspace/es680-setup/toolchain/usr/bin:$PATH"
cd /workspace/micro
python3 tools/buildFirmware.py Aula_21_Grupo_B2 /workspace/es680-build/aula21
python3 tools/checkProject.py \
  --elf /workspace/es680-build/aula21/Aula_21_Grupo_B2.elf
python3 tests/runTests.py
```

O último comando requer GCC nativo e suporte a AddressSanitizer,
UndefinedBehaviorSanitizer e LeakSanitizer. Na sessão Codex, executar fora
do sandbox de ptrace se LeakSanitizer relatar essa incompatibilidade.
Não é preciso instalar dependências Python. Em outra máquina, use caminho
de saída externo ao projeto; a ferramenta aceita dois argumentos:
diretório do projeto e diretório de saída. Não sobrescreve os fontes.

## Importar no STM32CubeIDE

Extraia o ZIP e use File > Import > General > Existing Projects into
Workspace, apontando para `Aula_21_Grupo_B2` (contém `.project` e
`Aula_21_Grupo_B2.ioc`). Não importe `Aula_20` como se fosse a entrega.
Faça backup, confira o `.ioc` na ferramenta conforme as pendências,
regenere com Keep User Code e arquivos por periférico, e execute
Project > Clean / Build Project. A base usa STM32Cube FW_G4 V1.5.2 e
CubeMX 6.8.1; qualquer migração precisa de revisão do diff e novo build.
Ainda não houve execução desses comandos no IDE nesta máquina.

## Documentação e entrega

- [Relatório das 12 etapas](RELATORIO_IMPLEMENTACAO.md).
- [Arquitetura e decisões](ARQUITETURA_DECISOES.md).
- [Matriz de conformidade](MATRIZ_CONFORMIDADE.md).
- [Manual de bancada T01–T16](MANUAL_TESTES_PLACA.md).
- [Pendências reais](PENDENCIAS_VALIDACAO.md).
- [Arquivos alterados em relação à base](ARQUIVOS_ALTERADOS.md).
- [Revisão das 11 regras e dos comentários](REVISAO_PADRONIZACAO.md).

`ES680_Aula21_GrupoB2_ENTREGA.zip` contém o projeto completo, documentação,
testes, ferramentas, imagens compiladas e logs, sem caches/objetos.
Nenhum commit/push ou envio ao professor é efetuado por estes comandos.
