# Manual de testes da entrega — Aula 21 / Grupo B2

> Firmware: `Aula_21_Grupo_B2/`, modo 21. Testes físicos: todos PENDENTES.
> Esta versão descreve o código entregue; os 59 cenários automatizados usam
> HAL simulada e não comprovam resultados em placa.

## 0. Quatro eventos para CINCO botões — pontos de observação

Os cinco botões **Cima, Baixo, Esquerda, Direita e Enter** devem gerar os eventos Pressed, Released, 500ms e 3s quando o tempo/estado correspondente existir. Não confundir geração de evento com ação visual: somente Cima, Baixo e Enter afetam os 4 LEDs segundo o slide 18.

**Teste de fronteira:** após cerca de 3s contínuos ocorrem **500ms e 3s no mesmo ciclo**; aos 3,5s, ocorre outro 500ms, mas o 3s não se repete. Ao soltar, todos os contadores e a flag de 3s daquele botão reiniciam. Um clique curto deve emitir Pressed e Released mesmo para Esquerda e Direita. Para observar eventos sem interromper a cronometragem, preferir contadores no debugger/live expressions, em vez de breakpoints suspensivos.

Ver `05_DECISOES_EVENTOS_E_MAQUINA_ESTADOS.md` para os cenários de 2,9 / 3,1 / 4,1 s e seus números esperados de callbacks.

## 1. O que o programa deve fazer

Ao ligar, os **quatro LEDs da placa Controlador de Temperatura** usados no contador devem mostrar zero (todos apagados). O sistema monitora **cinco botões físicos**, Cima, Baixo, Esquerda, Direita e Enter, com entradas de nível baixo quando soltas e nível alto quando pressionadas. Um clique curto deve gerar apenas um evento Pressed e um Released, mesmo que o contato elétrico oscile.

- **Cima:** uma pressão incrementa o contador **uma** unidade, após 10 ms de debounce; se continuar segurando, incrementa mais uma vez a **cada 500 ms**.
- **Baixo:** uma pressão decrementa o contador uma unidade, com repetição a cada 500 ms enquanto mantido.
- **Enter:** manter pressionado continuamente por **3 segundos** zera o contador e apaga os quatro LEDs; o evento de 3 s não se repete antes de soltar e pressionar novamente.
- **Esquerda/Direita:** a biblioteca detecta Pressed, Released, 500ms e 3s, mas não altera o contador demonstrativo. Observar eventos com breakpoints/contadores de diagnóstico, sem adicionar funcionalidades não pedidas.
- **Máximo do contador:** 4 bits (0 a 15). Aqui adotou-se módulo 16: 15+1=0 e 0−1=15. Isso é uma **decisão complementar** explicada no projeto, não texto explícito do slide 18.

## 2. Componentes físicos e conexões

Antes de energizar, conferir visualmente o kit e **o esquemático**. Não fazer/desfazer conexões com a placa energizada. Não forçar múltiplas teclas do teclado matricial da Aula 18 simultaneamente (o professor alerta para risco ao hardware). A atividade 21 utiliza os **cinco push-buttons independentes**, não as 16 teclas do teclado matricial e não o botão azul B1 da Nucleo.

| Controle | GPIO no STM32G474RE | Sinal/ação |
|---|---|---|
| Cima | PC1 | pressionar = nível 1 |
| Baixo | PC2 | pressionar = nível 1 |
| Esquerda | PC3 | pressionar = nível 1 |
| Direita | PC4 | pressionar = nível 1 |
| Enter | PB0 | pressionar = nível 1 |
| LED amarelo | PA4 | bit 3 = valor 8 |
| LED vermelho | PB14 | bit 2 = valor 4 |
| LED verde | PA12 | bit 1 = valor 2 |
| LED azul | PB5 | bit 0 = valor 1 |

O LED verde **PA5/LD2** da própria Nucleo não é necessário para exibir os quatro bits. As cores/pinos são confirmados pelo documento `Descrição dos pinos da Placa Contolador de Temperatura.pdf`. Se uma versão de placa inverter a lógica elétrica, validar no esquemático antes de trocar o sentido do GPIO.

## 3. Preparar o STM32CubeIDE

1. Descompactar `ES680_Aula21_GrupoB2_ENTREGA.zip`. A pasta do projeto é
   `Aula_21_Grupo_B2/`; documentação, testes e ferramentas ficam ao lado.
   Descompactar o projeto entregue pelo Codex em pasta local, evitando caminhos muito longos e caracteres especiais. Preferir uma pasta de trabalho separada do projeto da Aula 18.
2. Abrir STM32CubeIDE; selecionar `File > Import > Existing Projects into Workspace` (ou opção equivalente). Apontar para a pasta raiz onde há `.project` e `.ioc`.
3. O `.ioc` foi preparado manualmente porque CubeMX não está disponível
   na nuvem. Preservar cópia e validar sua configuração na ferramenta
   antes de regenerar. Não há importação/regeneração já comprovada.
   Inspecionar o arquivo `.ioc` **antes de alterar**: pinos PC1/2/3/4, PB0 com `GPIO_EXTI` rising+falling; EXTI0–4 no NVIC; TIM6 periódico 10 ms; TIM7 one-pulse 10 ms; TIM16 periódico 10 ms; LEDs como output. Conferir opção de arquivos separados `gpio.c/h`, `tim.c/h` se adotada.
4. Abrir Clock Configuration e calcular o tempo com `T = (PSC + 1)*(ARR + 1)/f_TIM`. Se f_TIM = 170 MHz, `PSC=169` e `ARR=9999` resultam em 10 ms. **Não assumir** que qualquer PCLK é igual a f_TIM sem verificar prescalers.
5. Fazer `Project > Clean` e `Build Project`. **Esperado:** zero erros e ausência de warnings relevantes do novo código. Se aparecerem erros de cabeçalhos `tim.h`, duplicidade de `HAL_TIM_PeriodElapsedCallback`, `undefined reference` para função, ou handler de TIM16, **não gravar**; corrigir primeiro.
6. Conectar Nucleo via USB/ST-LINK, verificar detecção do dispositivo e configuração SWD; montar placa externa conforme as conexões do kit. Fazer `Run` ou `Debug` e programar a Flash. Se Debug interromper em `main`, usar Resume para rodar.
7. Com sistema em execução, **sem pressionar qualquer botão**, verificar zero em todos os quatro LEDs.

## 4. Tabela visual do contador de 4 bits

Ordem: **amarelo(8), vermelho(4), verde(2), azul(1)**. Na tabela, `1` = LED aceso, `0` = apagado.

| Decimal | Binário (8 4 2 1) | Amarelo | Vermelho | Verde | Azul |
|---:|:---:|:---:|:---:|:---:|:---:|
| 0 | 0000 | 0 | 0 | 0 | 0 |
| 1 | 0001 | 0 | 0 | 0 | 1 |
| 2 | 0010 | 0 | 0 | 1 | 0 |
| 3 | 0011 | 0 | 0 | 1 | 1 |
| 4 | 0100 | 0 | 1 | 0 | 0 |
| 5 | 0101 | 0 | 1 | 0 | 1 |
| 6 | 0110 | 0 | 1 | 1 | 0 |
| 7 | 0111 | 0 | 1 | 1 | 1 |
| 8 | 1000 | 1 | 0 | 0 | 0 |
| 9 | 1001 | 1 | 0 | 0 | 1 |
| 10 | 1010 | 1 | 0 | 1 | 0 |
| 11 | 1011 | 1 | 0 | 1 | 1 |
| 12 | 1100 | 1 | 1 | 0 | 0 |
| 13 | 1101 | 1 | 1 | 0 | 1 |
| 14 | 1110 | 1 | 1 | 1 | 0 |
| 15 | 1111 | 1 | 1 | 1 | 1 |

## 5. Roteiro de testes — executar nesta ordem

**T01 — repouso e inicialização:** energizar, aguardar 2 segundos sem pressionar nada. Esperado `0000` estável. Reiniciar/resetar MCU e repetir. Verificar que nenhum LED muda sozinho.

**T02 — clique curto Cima:** dar um clique breve (por exemplo 100–200 ms), soltar. Esperado `0001`. Repetir e obter `0010`. Cada clique deve resultar em um único incremento; a liberação não altera LEDs.

**T03 — clique curto Baixo:** partindo de `0010`, clicar Baixo e soltar. Esperado `0001`. Clicar novamente -> `0000`.

**T04 — pressionar Cima por ~1,2 s:** após zerar, apertar e segurar Cima ~1,2 s e soltar. Esperado incrementos aos instantes aproximados **pressão validada**, **+0,5 s**, **+1,0 s** -> valor final `3`/`0011`. Nota: a confirmação de debounce e os ticks de TIM16 introduzem cerca de 10 ms de incerteza, não cronometre visualmente com precisão absoluta.

**T05 — segurar Baixo por ~1,2 s:** partindo de 3, segurar Baixo até passar de 1,0 s e antes de 1,5 s. Esperado 3 decrementos, retornando a 0.

**T06 — 500 ms repetidos:** segurar Cima por aproximadamente 2,2 s. Verificar o incremento inicial e eventos adicionais perto de 500, 1000, 1500 e 2000 ms; valor total +5. Soltar antes de novo 500 ms e verificar que a contagem para imediatamente após confirmar liberação.

**T07 — reset com Enter por 3 segundos:** primeiro ajustar contador para valor não zero (por exemplo 5). Pressionar Enter por 1 a 2 s: **não zerar**. Soltar. Pressionar Enter por mais de 3 s: valor passa a `0000` **uma vez**. Soltar e repetir depois de novo valor para comprovar que a flag de 3 s reinicializa.

**T08 — estados de Esquerda/Direita:** pressionar e soltar cada botão. LEDs **inalterados**. Usar debugger com breakpoints em `vButtonsEventCallbackPressedEvent`, `ReleasedEvent`, `500msPressedEvent` e `3sPressedEvent` ou em contadores de evento para confirmar cada botão sem ampliar escopo de UI. **Cuidado:** parar com breakpoint altera os tempos reais das interrupções; para medir 500 ms, preferir observação sem breakpoint ou instrumentation não bloqueante.

**T09 — anti-bounce:** clicar Cima rapidamente 10 vezes, com liberação completa entre cliques. Esperado contador +10 (mod 16), não +20 ou +30. Se houver contador de diagnóstico de `HAL_GPIO_EXTI_Callback`, ele pode subir múltiplas vezes devido a bounce; **o número de Pressed confirmados deve ser exatamente 10**. Não confundir EXTI bruta com evento validado.

**T10 — limite 15→0:** pressionar Cima 16 vezes a partir de 0. Esperado 15 após 15 cliques e `0000` após o décimo sexto.

**T11 — limite 0→15:** partindo de zero, pressionar Baixo uma vez. Esperado `1111` (amarelo, vermelho, verde e azul acesos).

**T12 — pressionamentos simultâneos em push-buttons (não no teclado 4×4):** Cima e Baixo são independentes. Confirmar que o debounce compartilhado não faz perder evento do segundo botão; a ordem de incrementos/decrementos depende do instante, mas o saldo de pressionamentos únicos Cima+Baixo deve ser zero módulo 16 se não alcançar 500 ms. Registrar caso real e explicar política de janela compartilhada.

**T13 — interleaving/repetição:** manter Cima pressionado por mais de 1 s, dar um clique breve em Esquerda ou Direita durante a pressão. Esperado a repetição de Cima continuar e o segundo botão gerar Pressed/Released sem sobrescrever estados do primeiro.

**T14 — confirmação do término de timer:** soltar todos. Esperado TIM16 parado; no debugger, verificar status do controle do TIM16 quando possível sem alterar o ciclo. Um clique subsequente deve reativá-lo corretamente.

**T15 — regressão TIM6/teclado matricial:** sem pressionar várias teclas simultaneamente, consultar no debugger a `struct xTeclado` ou `pMatrixKeyboardGetKeys()` enquanto pressiona uma tecla individual e verificar mudança; o código do teclado da Aula 18 não deve mexer na exibição binária do contador da Aula 21. Caso a integração do laboratório deliberadamente desative a varredura, registrar divergência e justificativa — o slide 13 sugere a coexistência.

**T16 — reset e pressão mantida na partida:** segurar Cima durante reset.
Esperado nesta implementação: contador fica zero, TIM16 parado, sem eventos.
Soltar apenas sincroniza a entrada (sem Released órfão). Pressionar novamente
gera Pressed e inicia a duração normalmente. Repetir com Enter e conferir
que não zera por uma pressão preexistente ao reset. Esta é decisão de partida,
não exigência literal do professor.

## 6. Ficha de execução dos testes (preencher na bancada)

| ID | Data/hora | Resultado (Passou/Falhou) | Evidência (foto/log/contagem) | Observações |
|---|---|---|---|---|
| T01 | — | PENDENTE | sem placa | executar na bancada |
| T02 | — | PENDENTE | sem placa | executar na bancada |
| T03 | — | PENDENTE | sem placa | executar na bancada |
| T04 | — | PENDENTE | sem placa | executar na bancada |
| T05 | — | PENDENTE | sem placa | executar na bancada |
| T06 | — | PENDENTE | sem placa | executar na bancada |
| T07 | — | PENDENTE | sem placa | executar na bancada |
| T08 | — | PENDENTE | sem placa | executar na bancada |
| T09 | — | PENDENTE | sem placa | executar na bancada |
| T10 | — | PENDENTE | sem placa | executar na bancada |
| T11 | — | PENDENTE | sem placa | executar na bancada |
| T12 | — | PENDENTE | sem placa | executar na bancada |
| T13 | — | PENDENTE | sem placa | executar na bancada |
| T14 | — | PENDENTE | sem placa | executar na bancada |
| T15 | — | PENDENTE | sem placa | executar na bancada |
| T16 | — | PENDENTE | sem placa | executar na bancada |

## 7. Diagnóstico rápido por sintoma

| Sintoma | Primeira verificação |
|---|---|
| Cima/baixo não funcionam | GPIO PC1/PC2 como EXTI **ambas** as bordas, IRQ habilitada, pull-down correto, HAL_GPIO_EXTI_Callback forte |
| Pressionar muda 2–3 unidades | Bounce, sinal estável sem filtro ou timer7/flags não impedindo callback duplicada |
| Clique funciona mas segurar não repete | TIM16 iniciado? Interrupt NVIC? Callback HAL roteia TIM16? relógio de 10 ms correto? |
| Segurar Enter não zera | Mapeamento PB0; contagem de 300 ticks; reset flag após liberar; 3s callback forte em main |
| Zera repetidamente após 3 s | Flag de evento 3s não é preservada até a soltura |
| Funciona uma vez e depois nunca mais | IRQ não reabilitada; pending não limpo; TIM7/OPM não rearma |
| Trocar de botão bloqueia primeiro | Desabilitação global de NVIC em vez de cada IRQ; timers de 10ms compartilhados sem flags |
| LEDs mudam sozinhos | Callbacks da Aula 18 ainda manipulam os mesmos LEDs; modo de teste incorreto |
| Alguns LEDs estão trocados | Mapping PA4/PB14/PA12/PB5, polaridade e fiação |
| Compila, mas não faz nada | Roteamento EXTI, init TIM7/TIM16, callbacks HAL, NVIC, blocos regenerados pelo CubeMX |
| Erros após regenerar CubeMX | Código escrito fora de `USER CODE`; dupla geração de `gpio.c/tim.c`; múltiplas definições |
| Botão PC13 funciona mas os cinco não | Confusão entre o botão B1 da Nucleo e a placa externa do laboratório |

## 8. Questões curtas de arguição — responda sem consultar o código

**Q1 — O que o EXTI faz?** Detecta bordas selecionadas de GPIOs e solicita tratamento ao NVIC; não é o próprio código da aplicação.

**Q2 — Por que são cinco fontes mas cinco IRQs nesta tarefa?** As linhas EXTI0–4 são individuais; PB0 ocupa EXTI0, PC1 EXTI1 etc. Em outros pinos há IRQs agrupadas, como EXTI9_5.

**Q3 — Por que precisamos detectar subida e descida?** Para identificar tanto a pressão (baixo→alto) quanto a liberação (alto→baixo) dos botões ativos em nível alto.

**Q4 — Por que a callback do EXTI não incrementa o contador imediatamente?** O contato pode trepidar; o evento confiável é emitido somente após TIM7 confirmar o estado 10 ms depois.

**Q5 — Por que TIM7 em One Pulse?** Uma detecção exige uma janela temporizada com uma interrupção no fim; o timer não precisa interromper continuamente quando não ocorre evento.

**Q6 — Como um TIM7 atende cinco botões?** Há cinco flags e estados, mas apenas um contador de hardware. Cada nova borda pendente pode reiniciar a janela, e ao fim são validados todos os estados pendentes.

**Q7 — Por que TIM16 separado de TIM7?** TIM7 confirma transições; TIM16 mede o tempo contínuo de botões já pressionados, a cada 10 ms.

**Q8 — Por que a callback de 3 s não se repete?** Uma flag registra que já disparou durante aquela pressão, e só é limpa após soltar.

**Q9 — Por que a callback HAL do timer fica no main?** O mesmo ponto da HAL recebe interrupções dos TIM6, TIM7 e TIM16; o main faz o roteamento para as três bibliotecas/funções pertinentes.

**Q10 — O que faz `__weak`?** Permite definir callback padrão na biblioteca, substituída por implementação forte em outro arquivo sem editar a biblioteca.

**Q11 — Qual o erro ao habilitar EXTI sem limpar pending?** Bounces ocorridos durante máscara deixam flags pendentes; ao habilitar, geram novas interrupções falsas.

**Q12 — Para que serve `volatile` aqui?** Ajuda a garantir visibilidade de variáveis modificadas por ISR, mas não torna atualizações compostas atômicas nem resolve corridas por si só.

**Q13 — Como calcular 10 ms?** `T=(PSC+1)*(ARR+1)/f_TIM`; com 170 MHz, `170 * 10000 / 170e6 = 0,010 s`.

**Q14 — O que é produzido pelo CubeMX e o que criamos?** Nesta entrega, GPIO/timers/NVIC e handlers foram adaptados manualmente
na nuvem a partir da base ST. O `.ioc` precisa ser validado e regenerado
no CubeMX; só após isso serão configurações geradas pela ferramenta.
Biblioteca, callbacks e aplicação são código próprio, em arquivos próprios
ou USER CODE. Ver `PENDENCIAS_VALIDACAO.md`.

**Q15 — Por que usar a Aula 18 como base?** Ela demonstra inicialização de TIM6, organização de bibliotecas e despachos de callbacks, e o slide 13 da Aula 21 explicita o caso de coexistência das três fontes.

**Q16 — O que a compilação não prova?** Não demonstra fiação, polaridade, comportamento de bouncing, tempo medido na placa ou ausência de falhas de integração física.

## 9. Conclusão exigida do Codex

O Codex deve atualizar este guia com os **nomes reais de funções, caminhos e configurações que efetivamente implementou**, eventuais nuances e status real de compilação. Fotos, gravação e observações de laboratório devem ser adicionadas **somente depois** do teste com a placa.


## Pontos reais para Live Expressions e inspeção

Em `main.c`: `ucMainCounter`, `ulButtonsPressed[0..4]`,
`ulButtonsReleased[0..4]`, `ulButtons500ms[0..4]`, `ulButtons3s[0..4]`.
Índices 0=Cima, 1=Baixo, 2=Esquerda, 3=Direita, 4=Enter.
São contadores acumulados desde reset; compare deltas entre cenários.
Não congele o núcleo para medir duração. Os quatro eventos existem mesmo
quando não há ação no display; Esquerda/Direita precisam desta observação.

TIM7 deve ter CR1.OPM=1 e CEN=0 em repouso; TIM16 CEN=0 sem pressão e 1
com pressão validada; TIM6 permanece ativo. O bit UIE deve acompanhar o
Start_IT/Stop_IT e os nomes dos vetores são TIM7_DAC_IRQHandler e
TIM1_UP_TIM16_IRQHandler. O mapa de bits é 8/4/2/1 como acima.

Testes de fronteira com instrumentação: Enter por 2,9s não zera, por 3,1s
zera uma vez. Em 3,0s são devidos o sexto 500ms e o primeiro 3s, nesta
ordem; em 3,5s há outro 500ms e nenhum novo 3s. Segurar Cima por 4,1s
partindo de zero termina em 9 (1 Pressed + 8 repetições). Esquerda ou
Direita por 3,1s gera 1 Pressed, 6 eventos 500ms, 1 evento 3s e 1 Released
sem mudar o contador. Usar margem para debounce e quantização de 10ms.
A duração conta a partir de Pressed confirmado; enquanto Release está
em debounce, ainda vale o último estado estável alto.

Na nuvem: `python3 tests/runTests.py` executa 59 cenários com os fontes
reais e HAL mínima, não T01–T16 físicos. Se LeakSanitizer relatar ptrace,
executar fora do sandbox de rastreamento; não desabilitar asserções.
