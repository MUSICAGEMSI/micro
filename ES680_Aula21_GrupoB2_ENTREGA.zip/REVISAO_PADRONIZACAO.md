# Revisão de padronização e comentários

Revisão de 3 de novembro de 2026, conforme as 11 regras da Aula 4.
Foram ajustados 11 arquivos da aplicação em `Core/Inc` e `Core/Src`.

Os comentários agora explicam o que acontece e por quê, sem narrar cada
linha: EXTI inicia o debounce; TIM7 confirma o botão; TIM16 mede a pressão;
TIM6 continua lendo o teclado; o main recebe os eventos e atualiza os LEDs.
Foram trocadas expressões como “update residual”, “eventos órfãos” e
“associação física imutável” por explicações diretas do funcionamento.

| Regra da Aula 4 | O que foi conferido |
|---|---|
| 1. Arquivos | Nomes próprios em camelCase e extensões `.c`/`.h`; nomes ST e dos slides preservados. |
| 2. Cabeçalhos | Arquivo, descrição, autoria, data e versão presentes. Autoria original mantida e revisão identificada. |
| 3. Ordem no `.c` | Includes, tipos, defines, variáveis e funções. As variáveis do teclado e do modo 2 foram reunidas antes das funções. |
| 4. Cabeçalhos `.h` | Guards conferidos e protótipos documentados. |
| 5. Comentários | `//` no corpo, curtos e ligados à lógica. Doxygen nas descrições; marcadores USER CODE preservados. |
| 6. Variáveis | Prefixos no código novo; nomes e campos da biblioteca herdada mantidos para compatibilidade. |
| 7. Funções | Nomes exigidos pelos slides e pela HAL mantidos. Não houve renomeação da API antiga apenas por estilo. |
| 8. Descrições | Doxygen das funções e protótipos próprios, com parâmetros e retorno quando cabível. O nome é identificado pela declaração associada ao bloco. |
| 9. Indentação | Dois espaços por nível, sem tabs nos arquivos revisados. |
| 10. Constantes | Maiúsculas nas constantes próprias; labels da HAL/CubeMX preservados. |
| 11. Linhas | Até 80 caracteres nos arquivos revisados. |

Não seria correto afirmar que todos os nomes do projeto seguem a regra
literal do código novo: `HAL_*`, `MX_*`, `GPIO_Pin`, `button_t` e os nomes
dos slides precisam permanecer como estão. Também foram mantidos nomes
herdados, como `vAtualizarLedsBinario`, `eBotao` e os campos `b1`, `b2`, etc.
Drivers, startup e demais arquivos ST continuam com o padrão original.
Isso evita alterar interfaces só para apresentar uma conformidade artificial.

Verificação: 41 corpos de funções sem mudança no código, declarações dos
cabeçalhos preservadas e BIN idêntico ao anterior. Build ARM sem avisos,
59 cenários aprovados e 81 arquivos Drivers idênticos à base.
Evidências em `evidencias/style.log`, `build.log`, `tests.log` e `audit.log`.
CubeMX e testes físicos continuam com as pendências já documentadas.
