# Arquitetura e decisões — Aula 21 / Grupo B2

Projeto: `Aula_21_Grupo_B2/`, cópia da Aula 18 v1.1 do pacote V2.
`Aula_20/` é o original recebido do GitHub e não foi alterado. A pasta
Drivers da entrega conserva exatamente os 81 arquivos da base do pacote.

## Caminho dos eventos

```text
PC1/PC2/PC3/PC4/PB0 -> EXTI1/2/3/4/0 -> handlers -> HAL
  -> HAL_GPIO_EXTI_Callback (main) -> vButtonsEventsExtiCallback
  -> máscara da linha + flag individual + reinício do TIM7 comum
  -> TIM7_DAC_IRQHandler -> dispatcher HAL (main), 10ms one-pulse
  -> amostra GPIO, comparação com estado estável, limpeza/rearme
  -> Pressed ou Released -> quatro callbacks fortes da aplicação

TIM16, 10ms periódico -> TIM1_UP_TIM16_IRQHandler -> mesmo dispatcher
  -> tempo individual -> 500ms repetitivo e 3s único por pressão

TIM6, 10ms periódico -> mesmo dispatcher -> wrapper matrixKeyboard
  -> algoritmo matricial herdado, sem efeitos nos LEDs em modo 21
```

O dispatcher compara `htim` com `pTimerMatrixKeyboard`,
`pTimerButtonsEventsDebouncing` e `pTimerButtonsEventsLongPress`,
preenchidos pelos respectivos Init. Não há callback HAL de aplicação
dentro de Drivers nem callback duplicada em bibliotecas.

## Mapa físico

| Enum / função | GPIO | IRQ ou bit |
|---|---|---|
| BUTTON_CIMA | PC1 | EXTI1 |
| BUTTON_BAIXO | PC2 | EXTI2 |
| BUTTON_ESQUERDA | PC3 | EXTI3 |
| BUTTON_DIREITA | PC4 | EXTI4 |
| BUTTON_ENTER | PB0 | EXTI0 |
| LED azul | PB5 | bit 0 / 1 |
| LED verde externo | PA12 | bit 1 / 2 |
| LED vermelho | PB14 | bit 2 / 4 |
| LED amarelo | PA4 | bit 3 / 8 |

Botões: active-high, pull-down externo descrito no slide 5; configurado
também pull-down interno, sem mudar a polaridade. Conferir o kit real.
LEDs seguem a lógica alta da Aula 18, ainda sem verificação elétrica nesta
placa. PC13/B1 é ignorado; PA5/LD2 não integra o contador. A matriz preserva
linhas PB15/13/12/11 e colunas PA10/PC9/PC8/PC7, sem conflito com botões.

## Estado e temporização

`buttonsEvents.c` contém tabela física constante e estado privado por
botão: nível aceito, pendência, indicação de botão alto no reset, contador
0–49 para 500ms, contador saturado 0–300 para 3s e flag de emissão única.
Dados privados `static` evitam acoplamento; só os ponteiros exigidos são
expostos. Não há RTOS, fila, timer por botão ou nova funcionalidade visual.

Init amostra os GPIOs com interrupções brevemente suspensas, preserva
PRIMASK, deixa TIM7/TIM16 parados. **Decisão de partida:** um botão alto
no reset é sincronizado como referência e ignorado até soltar; essa
soltura apenas arma a próxima pressão, sem Released órfão. A pressão
seguinte gera os quatro eventos normalmente. Este caso não é fixado pelo
enunciado e tem teste automatizado e roteiro T16.

Durante debounce só a IRQ da linha afetada é desabilitada. Bordas na mesma
linha são absorvidas pela janela; outra linha reinicia TIM7 e mantém as
flags anteriores. Ao expirar, Stop_IT devolve o estado HAL a READY mesmo
com CEN já desligado pelo OPM. EXTI->PR1 é limpo pela macro HAL e pending
NVIC pela função correspondente **antes da amostra final**; assim uma
borda posterior à amostra não é apagada. Após rearme, um pending novo
inicia outra janela e a comparação de estado impede duplicatas.
É uma amostragem após 10ms da primeira borda, não comprovação de sinal
contínuo sem ruído por 10ms. Pulsos curtos podem ser descartados; outras
linhas podem prolongar a janela comum e a latência.

A duração começa no Pressed confirmado. TIM16 inicia na primeira pressão
válida e para na última soltura. Outra pressão não reinicia o timer; apenas
seus contadores começam do zero. Primeiro tick pode ocorrer até 10ms
antes de completar um período cheio para esse novo botão. Enquanto uma
soltura espera debounce, o último estado aceito continua válido.

500ms acontece em 50,100,... ticks; 3s uma vez no tick 300. Na mesma marca,
500ms vem antes de 3s; 500ms continua em 350,400,... ticks. Release limpa
apenas o estado temporal do botão liberado. Para eventos simultâneos de
botões diferentes, a ordem é a do enum Cima/Baixo/Esquerda/Direita/Enter;
isso é determinismo de implementação, sem nova prioridade funcional.

## Aplicação e concorrência

Cima incrementa e Baixo decrementa em Pressed e 500ms. Enter zera em 3s.
Released, Esquerda e Direita não alteram LEDs. Módulo 16 e ordem no tick
300 são decisões do grupo, não texto literal do slide 18. Quatro arrays
de contadores `ulButtonsPressed`, `ulButtonsReleased`, `ulButtons500ms`,
`ulButtons3s` permitem observar os eventos no debugger sem inventar ações.

EXTI0–4, TIM6, TIM7 e TIM16 usam preempção 7/subprioridade 0. Eles não
interrompem uns aos outros; a atualização composta do contador e dos
estados fica serializada. SysTick pode interromper, mas não acessa estes
dados. O main inicializa antes de habilitar a biblioteca e depois não
altera seus estados. `volatile` no contador e diagnósticos serve à
observação, não à atomicidade; snapshots de vários contadores pelo
debugger não são atômicos. Se prioridades ou escritores mudarem, esta
garantia deve ser revista. Callbacks não podem bloquear nem chamar Init.

## Clock, configuração e limites

HSI 16MHz / PLLM4 * PLLN85 / PLLR2 = 170MHz. AHB/APB1/APB2 sem divisão:
TIM7 no APB1 e TIM16 no APB2 têm 170MHz. PSC169/ARR9999 geram 10ms.
TIM7 usa CR1.OPM; TIM16 periódico não usa OPM. UIF é limpo antes de Start_IT
para não contar o update de inicialização como um tick.

`gpio/tim/usart` e os handlers foram adaptados manualmente da base ST;
somente as rotinas de hardware ficam nas áreas que o gerador substituirá.
A aplicação fica em USER CODE e bibliotecas próprias; a opção CoupleFile
foi indicada no `.ioc`. O bit OPM foi também guardado em USER CODE do TIM7.
**Não houve execução do CubeMX:** o `.ioc` é configuração preparada para
revisão, inclusive OnePulseMode, não geração certificada. O laboratório
deve abrir, validar, gerar e repetir o build/testes conforme
`PENDENCIAS_VALIDACAO.md`. Não há teste físico ou importação IDE comprovados.
