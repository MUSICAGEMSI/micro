# Pendências reais de validação

O firmware foi compilado para ARM e sua lógica passou em 59 cenários de
HAL simulada. Isso não demonstra execução no STM32. Nenhum teste físico
foi feito, e nenhum resultado de placa foi preenchido como aprovado.

| Pendência | Motivo | Ação objetiva |
|---|---|---|
| Abrir/importar no CubeIDE | IDE ausente na nuvem | Importar a pasta com `.project`; nome deve ser Aula_21_Grupo_B2 |
| Validar schema e gerar `.ioc` | CubeMX ausente | Conferir GPIOs/IRQs, relógios, TIM7 OPM e TIM16; gerar em uma cópia |
| OnePulseMode de TIM7 no gerador | Parâmetro preparado manualmente | Confirmar reconhecimento em CubeMX 6.8.1 ou versão compatível; não aceitar migração silenciosa sem conferir CR1.OPM |
| Validar após regeneração | Não executada | Conferir USER CODE, ausência de callbacks/handles duplicados; Clean/Build e suíte novamente |
| Compilar pela toolchain do IDE | Build atual é GNU ARM 14.2.1 via CLI | Clean/Build do projeto importado com STM32Cube FW_G4 V1.5.2 ou migração revisada |
| Fiação e polaridade dos LEDs | Kit não conectado | Conferir PA4/PB14/PA12/PB5 e lógica alta antes do teste T01 |
| Gravação, clock real e temporização | Sem placa/ST-Link/osciloscópio | Medir 10ms, 500ms e 3s; verificar IRQs e cadência |
| Bounce e múltiplos botões físicos | HAL simulada não reproduz eletricidade | Executar T01–T16 e registrar evidências |

Preservar uma cópia da entrega antes de regenerar. Em Project Manager >
Code Generator, confirmar arquivos separados por periférico e Keep User
Code. O main deve inicializar GPIO/LPUART1/TIM6/TIM7/TIM16 exatamente uma
vez; a biblioteca nova registra `&htim7,&htim16` em USER CODE. Conferir
que `pTimerMatrixKeyboard` e o wrapper permanecem na biblioteca própria.

No CubeMX, conferir todos os clocks de timer em 170MHz; PSC=169/ARR=9999;
TIM7 single pulse e TIM16 contínuo. Os EXTI são PB0 e PC1–4 em ambas as
bordas/pull-down, não PC13. Igualar preempção 7 de EXTI/TIM6/TIM7/TIM16;
o código depende dessa serialização entre ISRs, não somente de volatile.

Não restam erros conhecidos de compilação ou testes de lógica. Testes de
hardware e integração do gerador continuam pendentes; a entrega não está
certificada como validada fisicamente nem como regenerada pelo CubeMX.
Nenhum email ao professor, commit ou push foi realizado nesta execução.
