# Arquivos da implementação

Comparação com a Aula 18 v1.1 do pacote, sem alterar essa referência.
O original `Aula_20/` do GitHub também permaneceu intacto.

| Arquivo na entrega | Tipo | Mudança |
|---|---|---|
| `.cproject` | modificado | Paths e projeto migrados |
| `.mxproject` | modificado | Metadados do projeto |
| `.project` | modificado | Nome de projeto consistente |
| `Aula_21_Grupo_B2.ioc` | novo | Substitui Aula_18.ioc; configuração manual a validar |
| `Core/Inc/buttonsEvents.h` | novo | Enum e API dos slides |
| `Core/Inc/gpio.h` | novo | Interface GPIO |
| `Core/Inc/main.h` | modificado | Labels dos cinco botões |
| `Core/Inc/matrixKeyboard.h` | modificado | Ponteiro/wrapper e descrições das funções |
| `Core/Inc/stm32g4xx_it.h` | modificado | Protótipos dos handlers |
| `Core/Inc/tim.h` | novo | Handles e interfaces dos timers |
| `Core/Inc/usart.h` | novo | Interface LPUART1 |
| `Core/Src/buttonsEvents.c` | novo | Estado e quatro eventos por botão |
| `Core/Src/gpio.c` | novo | Init GPIO separada, EXTI0–4 |
| `Core/Src/main.c` | modificado | Init, dispatcher, modo 21, eventos e LEDs |
| `Core/Src/matrixKeyboard.c` | modificado | Ponteiro TIM6, wrapper, limpeza de UIF no Init e revisão dos comentários/organização |
| `Core/Src/stm32g4xx_hal_msp.c` | modificado | MSP de periféricos movido para tim/usart |
| `Core/Src/stm32g4xx_it.c` | modificado | Cinco EXTI, TIM7_DAC, TIM1_UP_TIM16 |
| `Core/Src/tim.c` | novo | TIM6/7/16 e MSP |
| `Core/Src/usart.c` | novo | LPUART1 e MSP herdados separados |

91 arquivos preservados byte a byte; entre eles todos os 81
Drivers, startup e linker scripts. Não houve refatoração da varredura.

Fora do projeto: `tests/` (HAL mínima e 59 cenários), `tools/` (build,
auditoria e empacotamento), documentos na raiz, `evidencias/` (logs),
`binarios/` (ELF/HEX/BIN/MAP). Esses diretórios não entram no build Core/Drivers
do CubeIDE. O ZIP final é um artefato de entrega, sem objetos/caches.
