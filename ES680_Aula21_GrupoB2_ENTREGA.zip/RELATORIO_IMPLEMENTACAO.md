# Relatório de implementação — ES680 Aula 21, Grupo B2

Execução de 3 de novembro de 2026. A pedido do usuário, o pacote V2 passou
a orientar a implementação, além da preparação anterior do ambiente.

## 01 — Inventário e referências

**Pré-condição:** checkout inicialmente vazio, nenhum trabalho local.
**Alteração:** obtido o commit remoto
`01f1fd6f0bf69a429bce8e6149c93747a2b6c4e0` em `main`.
**Checagem:** o commit contém somente `Aula_20/`, projeto CubeIDE original,
sem biblioteca matricial ou drivers TIM. O pacote V2 reenviado tem o mesmo
SHA-256 `341b00b01cbfdd2a2bfa3656ea7f8b4a16ad9bcb7827374d7fff052b9b53d115`
do anexo anterior; seus 133 arquivos passam no manifesto.
**Resultado:** inventário concluído. A base da entrega será uma cópia da
Aula 18 v1.1, conforme o prompt; `Aula_20/` permanece intacto.

Árvore inicial: `Aula_20/{Core,Drivers,.project,.cproject,Aula_20.ioc,
STM32G474RETX_FLASH.ld,STM32G474RETX_RAM.ld,.settings,.mxproject}`.
Base do pacote: mesmos componentes, mais `matrixKeyboard.c/.h`, drivers
TIM/UART, TIM6 com PSC=169 e ARR=9999, PLL de 170 MHz.
`MODO_TESTE_ATIVIDADE=2` habilita callbacks legadas que escrevem nos LEDs;
serão neutralizadas por modo 21, preservando o algoritmo matricial.

Fontes lidas: PDFs originais das Aulas 21 (especialmente 5–18), 20 (29–36),
4 (regras 1–11), 18 (9–16), pinagem/layout, relato da videoaula,
documentos 02–07, prompt mestre e AGENTS do pacote. A imagem do slide 13
foi inspecionada para confirmar os nomes dos três ponteiros e dispatchers.
Referências completas permanecem nos anexos, não são requisitos novos.

Rastreabilidade principal: Aula21 5–6 = elétrica/pinagem; 7–10 = biblioteca,
Init e timers; 11 = EXTI; 12–13 = dispatcher; 14–17 = quatro eventos;
18 = ações nos LEDs; 19 = ZIP. Teoria20 29–31 = debounce compartilhado,
32–36 = duração; Aula18 15 = 3s único; Aula4 = padrão.

Decisões do grupo, não ordens literais: módulo 16; início da duração no
Pressed confirmado; ordem 500ms antes de 3s no tick 300; janela comum de
TIM7; latência/quantização de aproximadamente um tick para outro botão.

Limites conhecidos: GCC ARM disponível. STM32CubeMX/STM32CubeIDE e placa
não estão disponíveis. O prompt autoriza implementar C neste caso,
registrando a configuração/regeneração CubeMX como pendente; não será
declarada geração via CubeMX nem validação física.

## 02 — Cópia e build inicial

**Pré-condição:** base Aula 18 v1.1 identificada no pacote.
**Alteração:** cópia byte a byte dos 102 arquivos para `Aula_21_Grupo_B2/`.
**Checagem:** comparação SHA-256 de todos os arquivos e build ARM real de
25 unidades; text=15992, data=20, bss=1916; exit 0, sem avisos emitidos.
**Resultado:** base compilada antes das alterações. Startup confirma
`TIM7_DAC_IRQHandler` e `TIM1_UP_TIM16_IRQHandler`.

## 03 — Periféricos e configuração

**Pré-condição:** sem CubeMX/IDE na máquina, exceção prevista no prompt.
**Alteração:** nome de projeto migrado integralmente para `Aula_21_Grupo_B2`
em `.project`, `.cproject`, `.mxproject` e `.ioc`. Inicializações e MSP
separados em `gpio`, `tim`, `usart`, sem editar Drivers. Acrescentados GPIOs
PC1/2/3/4 e PB0 rising/falling/pull-down, IRQs EXTI0–4; TIM7 one-pulse
e TIM16 periódico; todos estes IRQs e TIM6 em prioridade de preempção 7.
**Checagem:** cálculo do clock mantido: HSI 16MHz /4 *85 /2 = 170MHz,
APB1=APB2=/1; TIM6/7/16: (169+1)*(9999+1)/170e6 = 10ms.
**Resultado:** C preparado e `.ioc` atualizado manualmente. Geração e
validação do `.ioc` no CubeMX permanecem PENDENTES, incluindo reconhecimento
do parâmetro OnePulseMode. O C usa CR1.OPM no bloco USER CODE de TIM7.
Não se afirma que estes arquivos tenham sido gerados pela ferramenta.

O build intermediário dos periféricos passou (28 unidades; text=16420,
data=20, bss=2068), antes da biblioteca nova. Nenhum aviso foi emitido.

## 04 — Interface pública

**Pré-condição:** `tim.h` disponível após separação dos periféricos.
**Alteração:** `buttonsEvents.h`, enum `button_t`, cinco botões, os dois
ponteiros extern, Init literal, duas rotinas temporizadas, quatro eventos
e delegação EXTI auxiliar. **Checagem:** conferência com slides 8 e 13–17
e compilação sintática ARM do cabeçalho, exit 0. **Resultado:** API criada.

## 05 — Estado, Init e callbacks fracas

**Pré-condição:** interface conferida. **Alteração:** `buttonsEvents.c`
com tabela física constante, estado privado por botão, Init que guarda os
handles, para os timers e amostra os GPIOs, quatro callbacks `__weak` sem
ação. Estado inicial alto fica inibido até soltar, evitando pressão criada
artificialmente no reset; depois inicia uma pressão nova normalmente.
**Checagem:** compilação ARM desta unidade e símbolos fracos/ponteiros.
**Resultado:** estrutura implementada; testes de comportamento virão na
etapa 11. Estado privado não exposto; diagnósticos da aplicação serão
`volatile`, não usados como mecanismo de exclusão mútua.

## 06 — Encaminhamento EXTI

**Pré-condição:** Init e quatro símbolos W conferidos com `nm`.
**Alteração:** callback HAL forte em USER CODE de `main.c`, cinco handlers
em `stm32g4xx_it.c`, delegação que mascara somente a IRQ encontrada,
limpa EXTI/NVIC, marca pendência e reinicia TIM7 via Stop/Start_IT.
**Checagem:** build ARM intermediário e inspeção de cada linha/handler.
**Resultado:** integração EXTI compilada. PC13 não corresponde à tabela e
não altera o contador. Uma falha de sintaxe no script auxiliar de edição
foi corrigida antes de qualquer edição pelo script; o build seguinte passou.

## 07 — Confirmação pelo TIM7

**Pré-condição:** EXTI encaminhado, estado por botão independente.
**Alteração:** TIM7 para no update, processa somente pendências, limpa
EXTI/NVIC ANTES da amostra final, rearma cada linha e compara com o último
nível estável. Gera apenas Pressed OU Released por mudança; reinicia
somente os acumuladores do botão alterado. **Checagem:** unidade ARM e
revisão da ordem de limpeza/amostragem/rearme. **Resultado:** debounce
implementado; cenários de bounce e dois botões serão executados na etapa 11.
Uma borda depois da limpeza fica pendente para a próxima janela; a
prioridade igual impede a nova EXTI de interromper a confirmação atual.

## 08 — Duração pelo TIM16

**Pré-condição:** debounce revisado e unidade ARM compilada (exit 0).
**Alteração:** TIM16 inicia na primeira pressão estável, não reinicia por
outro botão e para na última liberação. Cada botão mantém contador
cíclico 0–49 e contador saturado 0–300 com flag 3s. No tick 300 entrega
500ms e depois 3s; a repetição continua sem overflow dos acumuladores.
**Checagem:** unidade compilada para ARM, revisão dos limites e ausência
de HAL_Delay. **Resultado:** implementação concluída; testes temporais
determinísticos previstos na etapa 11, medição física pendente.

## 09 — TIM6 e dispatcher

**Pré-condição:** biblioteca nova compilada isoladamente.
**Alteração:** em `matrixKeyboard.c/.h`, somente o ponteiro TIM6, sua
atribuição em Init, limpeza de update inicial e wrapper delegado ao
algoritmo existente. `main.c` usa uma callback HAL que compara o handle
com os três ponteiros registrados, como na imagem do slide 13.
**Checagem:** build ARM da integração (29 unidades; text=18088, data=20,
bss=2124, exit 0, sem avisos) e inspeção dos três ramos.
**Resultado:** varredura matricial preservada; TIM7/TIM16 não usam TIM6.

## 10 — Aplicação dos quatro LEDs

**Pré-condição:** dispatcher compilado, biblioteca nova ligada.
**Alteração:** modo 21 neutraliza somente efeitos visuais das callbacks
legadas. Quatro callbacks fortes, contador módulo 16, Cima +1 em Pressed
e 500ms, Baixo -1 nos mesmos eventos, Enter zera só em 3s. Released,
Esquerda e Direita apenas atualizam contadores de diagnóstico observáveis
`ulButtonsPressed/Released/500ms/3s`; PA5 não integra o display.
**Checagem:** build ARM real (29 unidades; text=18236, data=20, bss=2204,
exit 0, sem avisos) e teste lógico das ações na etapa seguinte.
**Resultado:** aplicação compilada. Inicializa em zero. Não há trabalho
bloqueante nas callbacks; HAL_Delay(50) herdado só permanece no laço main.

## 11 — Testes e revisão

**Pré-condição:** firmware integrado compilado em ARM.
**Alteração:** ferramentas portáveis `tools/buildFirmware.py`,
`tools/checkProject.py` e testes em `tests/`, fora das entradas de fontes
Core/Drivers do CubeIDE. O teste compila a biblioteca real e a biblioteca
matricial real; extrai do main os próprios blocos USER CODE, sem reescrever
as ações/dispatcher. GPIO/NVIC/timers são uma HAL mínima, não um emulador
de STM32 nem uma medição temporal física.

**Checagem:** 59 cenários concluídos com `gcc -Wall -Wextra -Werror`,
AddressSanitizer, UndefinedBehaviorSanitizer e LeakSanitizer, exit 0.
São 50 combinações (5 botões x 10 durações: 100,490,500,1200,2900,2990,
3000,3100,4100,700000 ms em ticks nominais), mais 9 casos compostos:
bounce/pulso/segundo clique; janela compartilhada; independência temporal;
fronteira e ordem 500ms/3s/rearme; módulo 16; reset pressionado; PC13/timer
desconhecido/matriz/isolamento LEDs; borda entre amostra e rearme; PRIMASK.
Os cinco botões produzem as quatro callbacks com identidade correta.
O teste de 70000 ticks comprova repetição prolongada sem overflow dos
acumuladores saturados; não constitui teste de 700 segundos em hardware.

A primeira instrumentação de ordem usou `--wrap`, que não intercepta
referências resolvidas na mesma unidade que define o weak; isso causou
falha no harness. Foi substituída por instrumentação de entrada de função
do GCC, preservando as callbacks reais e as asserções. Todos os testes
depois passaram. LeakSanitizer exige execução sem ptrace: o sandbox
impediu a finalização, então a suíte foi executada fora do sandbox, com
todos os sanitizadores habilitados, exit 0.

Auditoria estática: 81 arquivos Drivers byte a byte idênticos ao pacote;
nomes/XML do projeto consistentes; `.ioc` e C com GPIOs/NVIC/timers previstos;
callbacks únicas no Core, quatro weak na biblioteca, quatro strong no main,
três rotas por ponteiros; símbolos de eventos/HAL/IRQs T no ELF e zero
símbolos indefinidos. A ferramenta não valida o schema interno do CubeMX.

Regras Aula4: camelCase para arquivos próprios/API pedida; cabeçalhos
Doxygen com autoria real da adaptação; includes/tipos/defines/estado/funções;
guards; comentários locais `//`; prefixos; documentação de funções novas;
dois espaços; constantes maiúsculas; máximo de 80 colunas nos módulos
novos de firmware. Nomes, estilo e copyright do código ST/legado foram
preservados onde possível, sem alegar refatoração/conformidade MISRA.
Os arquivos de configuração manual `tim/gpio/usart` mantêm os nomes e as
interfaces esperadas do gerador. O algoritmo matricial original não foi
reescrito. A pasta `Aula_20` do commit permanece sem modificações.

**Resultado:** compilação e testes de lógica aprovados; geração/importação
CubeIDE, integração após regeneração e todos os testes físicos pendentes.

## 12 — Documentos e pacote final

**Pré-condição:** 59 cenários e build final aprovados; limites conhecidos.
**Alteração:** README, arquitetura, matriz R01–R34, relação de arquivos,
manual T01–T16 e pendências atualizados para os nomes e decisões reais.
ZIP `ES680_Aula21_GrupoB2_ENTREGA.zip` contém projeto completo Core/Drivers,
`.ioc`, `.project`, `.cproject`, startup/linkers, testes e ferramentas,
documentação, binários ELF/HEX/BIN/MAP e logs em `evidencias/`.
Sem objetos, caches de compilação ou dependências externas baixadas.
**Checagem:** CRC e manifesto SHA-256 de cada entrada. ZIP extraído em
diretório independente, build portátil de 29 unidades executado e auditado
com exit 0. O conteúdo não depende dos fontes fora do pacote; o compilador
ARM/newlib permanece um requisito do host. `Aula_20/` não foi modificado.
**Resultado:** entrega editável empacotada e recompilada a partir do ZIP.
Importação real/regeneração no IDE e testes de placa continuam PENDENTES.

## Estado final das 12 etapas

| Etapa | Estado verificável |
|---|---|
| 01 Inventário | concluído, fontes/commit/pinagem registrados |
| 02 Cópia/base | compilado antes de alterar |
| 03 GPIO/timers/IOC | C compilado; geração CubeMX PENDENTE |
| 04 Interface | implementado e compilado |
| 05 Estado/Init/weak | implementado, compilado, testado em HAL mínima |
| 06 EXTI | implementado, compilado, testado em HAL mínima |
| 07 TIM7 | implementado, compilado, testado em HAL mínima |
| 08 TIM16 | implementado, compilado, testado em HAL mínima |
| 09 TIM6/dispatcher | implementado, compilado, regressão lógica aprovada |
| 10 Aplicação | implementado, compilado, LEDs simulados aprovados |
| 11 Build/revisão | 29 unidades ARM, 59 cenários e auditoria aprovados |
| 12 Entrega | ZIP/manifesto/build extraído aprovados; IDE/placa PENDENTES |

Nenhuma etapa foi validada fisicamente. Logs: `evidencias/build.log`,
`tests.log`, `audit.log`, `package.log`. O build final em Flash tem
text=18236, data=20 e bss=2204 bytes; sem avisos emitidos e sem símbolos
indefinidos. Configuração reutilizável do ambiente também foi atualizada,
sem publicação automática. Alterações ficam locais e revisáveis: não foi
feito commit, push ou envio ao professor.

## Revisão posterior — padronização e clareza dos comentários

A pedido do usuário, foram revisados 11 arquivos da aplicação, com foco
nas 11 regras da Aula 4 e em explicações simples do funcionamento.
Foram completadas as descrições Doxygen do teclado e das funções antigas
do main, reunidas as variáveis antes das funções e simplificados os
comentários sobre debounce, timers, eventos e LEDs. Autoria e interfaces
herdadas foram preservadas. As exceções dos nomes ST/HAL e do código
anterior estão em `REVISAO_PADRONIZACAO.md`, sem alegação de conformidade
literal de todos os nomes gerados.

A auditoria passou a incluir main e matrixKeyboard, verificando também
guards, descrições, parâmetros e retornos. Os 41 corpos de funções
revisados mantêm o mesmo código; os cabeçalhos mantêm as declarações.
O BIN recompilado é idêntico byte a byte ao anterior, com SHA-256
`bfb54df970afe9975d92ff2e50f111fa1dec304fe35510045ba69c158e8a5b22`.
Build de 29 unidades e os mesmos 59 cenários passaram novamente.
Os binários, referências de linha, evidências e ZIP foram atualizados.
