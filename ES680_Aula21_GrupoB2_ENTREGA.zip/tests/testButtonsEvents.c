/**
 * @file testButtonsEvents.c
 * @brief Testes da lógica real com GPIOs e timers controlados pelo teste.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 2.0
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "appUser.c"

GPIO_TypeDef xTestA, xTestB, xTestC;
TIM_HandleTypeDef htim6, htim7, htim16;
static uint16_t usEnabled, usExtiPending, usNvicPending;
static uint32_t ulPrimask;
static unsigned int uiCases;
static unsigned int uiEventCount;
static uint8_t ucEventOrder[4096];
static uint8_t ucInjectAfterRead;
static const uint16_t usPins[BUTTON_TOTAL] =
  {GPIO_PIN_1, GPIO_PIN_2, GPIO_PIN_3, GPIO_PIN_4, GPIO_PIN_0};
static const IRQn_Type xIrqs[BUTTON_TOTAL] =
  {EXTI1_IRQn, EXTI2_IRQn, EXTI3_IRQn, EXTI4_IRQn, EXTI0_IRQn};

void __cyg_profile_func_enter(void *pFunction, void *pCaller)
  __attribute__((no_instrument_function));
void __cyg_profile_func_exit(void *pFunction, void *pCaller)
  __attribute__((no_instrument_function));
void __cyg_profile_func_enter(void *pFunction, void *pCaller)
{
  UNUSED(pCaller);
  if ((pFunction == (void *)vButtonsEventCallback500msPressedEvent) ||
      (pFunction == (void *)vButtonsEventCallback3sPressedEvent))
  {
    assert(uiEventCount < sizeof(ucEventOrder));
    ucEventOrder[uiEventCount++] =
      (pFunction == (void *)vButtonsEventCallback3sPressedEvent) ? 3U : 5U;
  }
}
void __cyg_profile_func_exit(void *pFunction, void *pCaller)
{
  UNUSED(pFunction);
  UNUSED(pCaller);
}
void Error_Handler(void) { abort(); }
uint32_t __get_PRIMASK(void) { return ulPrimask; }
void __disable_irq(void) { ulPrimask = 1U; }
void __set_PRIMASK(uint32_t ulMask) { ulPrimask = ulMask; }
void vTestClearExti(uint16_t usPin) { usExtiPending &= ~usPin; }
void HAL_NVIC_EnableIRQ(IRQn_Type xIrq) { usEnabled |= 1U << xIrq; }
void HAL_NVIC_DisableIRQ(IRQn_Type xIrq) { usEnabled &= ~(1U << xIrq); }
void HAL_NVIC_ClearPendingIRQ(IRQn_Type xIrq)
{
  usNvicPending &= ~(1U << xIrq);
}
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *pPort, uint16_t usPin)
{
  GPIO_PinState xLevel = (pPort->idr & usPin) ? GPIO_PIN_SET : GPIO_PIN_RESET;
  if ((ucInjectAfterRead != 0U) && (pPort == GPIOC) &&
      (usPin == GPIO_PIN_1))
  {
    ucInjectAfterRead = 0U;
    pPort->idr &= ~usPin;
    usExtiPending |= usPin;
    usNvicPending |= 1U << EXTI1_IRQn;
  }
  return xLevel;
}
void HAL_GPIO_WritePin(GPIO_TypeDef *pPort, uint16_t usPin,
                       GPIO_PinState xLevel)
{
  if (xLevel == GPIO_PIN_SET) { pPort->odr |= usPin; }
  else { pPort->odr &= ~usPin; }
}
void HAL_GPIO_TogglePin(GPIO_TypeDef *pPort, uint16_t usPin)
{
  pPort->odr ^= usPin;
}
HAL_StatusTypeDef HAL_TIM_Base_Start_IT(TIM_HandleTypeDef *pTimer)
{
  assert(pTimer->active == 0U);
  assert((pTimer->flags & TIM_FLAG_UPDATE) == 0U);
  pTimer->active = 1U;
  pTimer->starts++;
  return HAL_OK;
}
HAL_StatusTypeDef HAL_TIM_Base_Stop_IT(TIM_HandleTypeDef *pTimer)
{
  pTimer->active = 0U;
  return HAL_OK;
}

static void vReset(uint8_t ucValue)
{
  xTestA = xTestB = xTestC = (GPIO_TypeDef){0};
  htim6 = htim7 = htim16 = (TIM_HandleTypeDef){0};
  htim6.flags = htim7.flags = htim16.flags = TIM_FLAG_UPDATE;
  usEnabled = usExtiPending = usNvicPending = 0U;
  ulPrimask = 0U;
  ucInjectAfterRead = 0U;
  uiEventCount = 0U;
  for (uint8_t ucBt = 0U; ucBt < BUTTON_TOTAL; ucBt++)
  {
    ulButtonsPressed[ucBt] = ulButtonsReleased[ucBt] = 0U;
    ulButtons500ms[ucBt] = ulButtons3s[ucBt] = 0U;
  }
  ucMainCounter = ucValue;
  vAtualizarLedsBinario(ucMainCounter);
  vMatrixKeyboardInit(&htim6);
  vButtonsEventsInit(&htim7, &htim16);
  assert(htim7.active == 0U && htim16.active == 0U);
  assert(ulPrimask == 0U && (usEnabled & 31U) == 31U);
}
static void vDeliver(button_t xBt)
{
  uint16_t usBit = 1U << xIrqs[xBt];
  if ((usEnabled & usBit) && (usNvicPending & usBit))
  {
    usNvicPending &= ~usBit;
    vTestClearExti(usPins[xBt]);
    HAL_GPIO_EXTI_Callback(usPins[xBt]);
  }
}
static void vEdge(button_t xBt, GPIO_PinState xLevel)
{
  GPIO_TypeDef *pPort = xBt == BUTTON_ENTER ? GPIOB : GPIOC;
  if (xLevel == GPIO_PIN_SET) { pPort->idr |= usPins[xBt]; }
  else { pPort->idr &= ~usPins[xBt]; }
  usExtiPending |= usPins[xBt];
  usNvicPending |= 1U << xIrqs[xBt];
  vDeliver(xBt);
}
static void vDebounce(void)
{
  assert(htim7.active != 0U);
  htim7.active = 0U; // CEN cai em hardware no one-pulse.
  HAL_TIM_PeriodElapsedCallback(&htim7);
}
static void vChange(button_t xBt, GPIO_PinState xLevel)
{
  vEdge(xBt, xLevel);
  vDebounce();
}
static void vTicks(unsigned int uiTicks)
{
  for (unsigned int uiTick = 0U; uiTick < uiTicks; uiTick++)
  {
    if (htim16.active) { HAL_TIM_PeriodElapsedCallback(&htim16); }
  }
}
static void vCheckLeds(uint8_t ucValue)
{
  assert(((GPIOB->odr & GPIO_PIN_5) != 0U) == ((ucValue & 1U) != 0U));
  assert(((GPIOA->odr & GPIO_PIN_12) != 0U) == ((ucValue & 2U) != 0U));
  assert(((GPIOB->odr & GPIO_PIN_14) != 0U) == ((ucValue & 4U) != 0U));
  assert(((GPIOA->odr & GPIO_PIN_4) != 0U) == ((ucValue & 8U) != 0U));
  assert((GPIOA->odr & GPIO_PIN_5) == 0U);
}
int main(void)
{
  setvbuf(stdout, NULL, _IONBF, 0);
  const unsigned int uiDurations[] =
    {10U, 49U, 50U, 120U, 290U, 299U, 300U, 310U, 410U, 70000U};
  for (button_t xBt = BUTTON_CIMA; xBt < BUTTON_TOTAL; xBt++)
  {
    for (unsigned int uiD = 0; uiD < 10U; uiD++)
    {
      unsigned int uiTicks = uiDurations[uiD];
      unsigned int uiRepeats = uiTicks / 50U;
      uint8_t ucExpected = 5U;
      vReset(5U);
      vEdge(xBt, GPIO_PIN_SET);
      assert(ulButtonsPressed[xBt] == 0U && htim16.active == 0U);
      vDebounce();
      assert(ulButtonsPressed[xBt] == 1U);
      vTicks(uiTicks);
      assert(ulButtons500ms[xBt] == uiRepeats);
      assert(ulButtons3s[xBt] == (uiTicks >= 300U ? 1U : 0U));
      if (xBt == BUTTON_CIMA) { ucExpected = (6U + uiRepeats) & 15U; }
      if (xBt == BUTTON_BAIXO) { ucExpected = (4U - uiRepeats) & 15U; }
      if (xBt == BUTTON_ENTER && uiTicks >= 300U) { ucExpected = 0U; }
      assert(ucMainCounter == ucExpected);
      vCheckLeds(ucExpected);
      vChange(xBt, GPIO_PIN_RESET);
      assert(ulButtonsReleased[xBt] == 1U && htim16.active == 0U);
      assert(usExtiPending == 0U && usNvicPending == 0U);
      assert((usEnabled & 31U) == 31U);
      assert(ucMainCounter == ucExpected);
      uiCases++;
    }
  }
  puts("PASS: 50 cenários (5 botões x 10 durações), ações e mapa dos LEDs");

  vReset(0U);
  vEdge(BUTTON_CIMA, GPIO_PIN_SET);
  vEdge(BUTTON_CIMA, GPIO_PIN_RESET);
  vDebounce();
  assert(ulButtonsPressed[0] == 0U && htim16.active == 0U);
  vEdge(BUTTON_CIMA, GPIO_PIN_SET);
  vEdge(BUTTON_CIMA, GPIO_PIN_RESET);
  vEdge(BUTTON_CIMA, GPIO_PIN_SET);
  vDebounce();
  vChange(BUTTON_CIMA, GPIO_PIN_SET); // Ruído sem alteração estável.
  assert(ulButtonsPressed[0] == 1U);
  vChange(BUTTON_CIMA, GPIO_PIN_RESET);
  vChange(BUTTON_CIMA, GPIO_PIN_SET);
  assert(ulButtonsPressed[0] == 2U && ulButtonsReleased[0] == 1U);
  uiCases++;
  puts("PASS: bounce, pulso rejeitado, evento espúrio e segundo clique");

  vReset(0U);
  vEdge(BUTTON_CIMA, GPIO_PIN_SET);
  assert((usEnabled & (1U << EXTI2_IRQn)) != 0U);
  vEdge(BUTTON_BAIXO, GPIO_PIN_SET);
  assert(htim7.starts == 2U);
  vDebounce();
  assert(ulButtonsPressed[0] == 1U && ulButtonsPressed[1] == 1U);
  assert(htim16.starts == 1U && ucMainCounter == 0U);
  uiCases++;
  puts("PASS: janela TIM7 compartilhada, máscara individual e dois botões");

  vReset(0U);
  vChange(BUTTON_CIMA, GPIO_PIN_SET);
  vTicks(30U);
  vChange(BUTTON_ESQUERDA, GPIO_PIN_SET);
  vTicks(20U);
  assert(ulButtons500ms[0] == 1U && ulButtons500ms[2] == 0U);
  assert(htim16.starts == 1U);
  vChange(BUTTON_CIMA, GPIO_PIN_RESET);
  assert(htim16.active != 0U);
  vTicks(30U);
  assert(ulButtons500ms[2] == 1U);
  vChange(BUTTON_ESQUERDA, GPIO_PIN_RESET);
  assert(htim16.active == 0U);
  uiCases++;
  puts("PASS: tempos independentes, liberação parcial e parada do TIM16");

  vReset(5U);
  vChange(BUTTON_ENTER, GPIO_PIN_SET);
  vTicks(299U);
  assert(ulButtons3s[4] == 0U && ucMainCounter == 5U);
  vTicks(1U);
  assert(uiEventCount >= 2U);
  assert(ucEventOrder[uiEventCount - 2U] == 5U);
  assert(ucEventOrder[uiEventCount - 1U] == 3U);
  vTicks(50U);
  assert(ulButtons500ms[4] == 7U && ulButtons3s[4] == 1U);
  vChange(BUTTON_ENTER, GPIO_PIN_RESET);
  vChange(BUTTON_ENTER, GPIO_PIN_SET);
  vTicks(300U);
  assert(ulButtons3s[4] == 2U);
  uiCases++;
  puts("PASS: fronteira 299/300 ticks, ordem 500ms/3s, repetição e rearme");

  vReset(15U);
  vChange(BUTTON_CIMA, GPIO_PIN_SET);
  assert(ucMainCounter == 0U);
  vChange(BUTTON_CIMA, GPIO_PIN_RESET);
  vChange(BUTTON_BAIXO, GPIO_PIN_SET);
  assert(ucMainCounter == 15U);
  vCheckLeds(15U);
  uiCases++;
  puts("PASS: limites 15+1=0 e 0-1=15");

  vReset(0U);
  GPIOC->idr = GPIO_PIN_1;
  vButtonsEventsInit(&htim7, &htim16);
  vTicks(400U);
  assert(ulButtonsPressed[0] == 0U && htim16.active == 0U);
  vChange(BUTTON_CIMA, GPIO_PIN_RESET);
  assert(ulButtonsReleased[0] == 0U);
  vChange(BUTTON_CIMA, GPIO_PIN_SET);
  vTicks(50U);
  assert(ulButtonsPressed[0] == 1U && ulButtons500ms[0] == 1U);
  uiCases++;
  puts("PASS: botão alto no reset espera soltura e aceita nova pressão");

  vReset(0U);
  HAL_GPIO_EXTI_Callback(GPIO_PIN_13);
  assert(htim7.active == 0U && ucMainCounter == 0U);
  TIM_HandleTypeDef xUnknown = {0};
  HAL_TIM_PeriodElapsedCallback(&xUnknown);
  assert(htim7.active == 0U && ucMainCounter == 0U);
  vMatrixKeyboard500msPressedCallback(KEY_1);
  vMatrixKeyboardThreeSecPressedCallback(KEY_1);
  vCheckLeds(0U);
  GPIOB->idr = GPIO_PIN_15;
  for (int i = 0; i < 4; i++) { HAL_TIM_PeriodElapsedCallback(&htim6); }
  assert(pMatrixKeyboardGetKeys()->b1 == 1);
  assert(pMatrixKeyboardGetKeys()->ba == 1);
  assert(htim6.active != 0U && htim16.active == 0U);
  vCheckLeds(0U);
  uiCases++;
  puts("PASS: PC13 ignorado, TIM desconhecido, matriz real e LEDs isolados");

  vReset(0U);
  vEdge(BUTTON_CIMA, GPIO_PIN_SET);
  ucInjectAfterRead = 1U;
  vDebounce();
  assert(ulButtonsPressed[0] == 1U);
  assert((usExtiPending & GPIO_PIN_1) != 0U);
  vDeliver(BUTTON_CIMA);
  vDebounce();
  assert(ulButtonsReleased[0] == 1U && htim16.active == 0U);
  uiCases++;
  puts("PASS: borda após amostragem não é apagada pelo rearme");

  vReset(0U);
  ulPrimask = 1U;
  vButtonsEventsInit(&htim7, &htim16);
  assert(ulPrimask == 1U);
  uiCases++;
  puts("PASS: inicialização preserva o PRIMASK anterior");
  printf("%u cenários concluídos; HAL simulada, sem testes físicos.\n",
         uiCases);
  return 0;
}
