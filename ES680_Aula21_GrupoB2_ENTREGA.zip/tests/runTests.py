#!/usr/bin/env python3
"""Exercise the real library, matrix and main USER CODE against a fake HAL."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
project = root / 'Aula_21_Grupo_B2'
main = (project / 'Core/Src/main.c').read_text()

def region(name):
    begin = f'/* USER CODE BEGIN {name} */'
    end = f'/* USER CODE END {name} */'
    assert main.count(begin) == main.count(end) == 1, name
    return main.split(begin, 1)[1].split(end, 1)[0]

with tempfile.TemporaryDirectory(prefix='es680-tests-') as directory:
    work = Path(directory)
    (work / 'appUser.c').write_text('\n'.join(region(s) for s in
        ['Includes', 'PTD', 'PD', 'PM', 'PV', 'PFP', '4']))
    binary = work / 'testButtonsEvents'
    command = ['gcc', '-std=c11', '-g', '-O1', '-Wall', '-Wextra', '-Werror',
        '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
        '-finstrument-functions',
        '-I', str(root / 'tests/hal'), '-I', str(project / 'Core/Inc'),
        '-I', str(work), str(root / 'tests/testButtonsEvents.c'),
        str(project / 'Core/Src/buttonsEvents.c'),
        str(project / 'Core/Src/matrixKeyboard.c'), '-o', str(binary)]
    subprocess.run(command, check=True)
    subprocess.run([str(binary)], check=True)
