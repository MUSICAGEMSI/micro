/**
 * @file stm32g4xx_hal.h
 * @brief HAL mínima para testes nativos; não emula o microcontrolador.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 2.0
 */
#ifndef TESTHAL_H
#define TESTHAL_H
#include <stddef.h>
#include <stdint.h>

#define __weak __attribute__((weak))
#define UNUSED(x) ((void)(x))
#define TIM_FLAG_UPDATE 1U
#define GPIO_PIN_0 (1U << 0)
#define GPIO_PIN_1 (1U << 1)
#define GPIO_PIN_2 (1U << 2)
#define GPIO_PIN_3 (1U << 3)
#define GPIO_PIN_4 (1U << 4)
#define GPIO_PIN_5 (1U << 5)
#define GPIO_PIN_7 (1U << 7)
#define GPIO_PIN_8 (1U << 8)
#define GPIO_PIN_9 (1U << 9)
#define GPIO_PIN_10 (1U << 10)
#define GPIO_PIN_11 (1U << 11)
#define GPIO_PIN_12 (1U << 12)
#define GPIO_PIN_13 (1U << 13)
#define GPIO_PIN_14 (1U << 14)
#define GPIO_PIN_15 (1U << 15)

typedef enum { GPIO_PIN_RESET, GPIO_PIN_SET } GPIO_PinState;
typedef enum { HAL_OK, HAL_ERROR } HAL_StatusTypeDef;
typedef enum { EXTI0_IRQn, EXTI1_IRQn, EXTI2_IRQn, EXTI3_IRQn,
               EXTI4_IRQn, EXTI15_10_IRQn } IRQn_Type;
typedef struct { uint16_t idr, odr; } GPIO_TypeDef;
typedef struct
{
  void *Instance;
  uint32_t counter, flags;
  unsigned int starts;
  uint8_t active;
} TIM_HandleTypeDef;
typedef struct { void *Instance; } UART_HandleTypeDef;
extern GPIO_TypeDef xTestA, xTestB, xTestC;
#define GPIOA (&xTestA)
#define GPIOB (&xTestB)
#define GPIOC (&xTestC)

#define __HAL_TIM_SET_COUNTER(p, n) ((p)->counter = (n))
#define __HAL_TIM_CLEAR_FLAG(p, n) ((p)->flags &= ~(n))
#define __HAL_GPIO_EXTI_CLEAR_IT(n) vTestClearExti(n)

void vTestClearExti(uint16_t usPin);
uint32_t __get_PRIMASK(void);
void __disable_irq(void);
void __set_PRIMASK(uint32_t ulMask);
GPIO_PinState HAL_GPIO_ReadPin(GPIO_TypeDef *pPort, uint16_t usPin);
void HAL_GPIO_WritePin(GPIO_TypeDef *pPort, uint16_t usPin,
                       GPIO_PinState xLevel);
void HAL_GPIO_TogglePin(GPIO_TypeDef *pPort, uint16_t usPin);
void HAL_NVIC_EnableIRQ(IRQn_Type xIrq);
void HAL_NVIC_DisableIRQ(IRQn_Type xIrq);
void HAL_NVIC_ClearPendingIRQ(IRQn_Type xIrq);
HAL_StatusTypeDef HAL_TIM_Base_Start_IT(TIM_HandleTypeDef *pTimer);
HAL_StatusTypeDef HAL_TIM_Base_Stop_IT(TIM_HandleTypeDef *pTimer);

#endif // TESTHAL_H
