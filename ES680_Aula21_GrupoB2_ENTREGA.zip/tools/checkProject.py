#!/usr/bin/env python3
"""Static consistency checks; not a CubeMX parser or a physical validation."""
import argparse
from pathlib import Path
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--elf', type=Path)
parser.add_argument('--base', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
project = root / 'Aula_21_Grupo_B2'
name = project.name
assert ET.parse(project / '.project').findtext('name') == name
ET.parse(project / '.cproject')
assert 'Aula_18' not in (project / '.cproject').read_text()
cfg = dict(line.split('=', 1) for line in
           (project / (name + '.ioc')).read_text().splitlines() if '=' in line)
assert cfg['ProjectManager.ProjectName'] == name
assert cfg['ProjectManager.ProjectFileName'] == name + '.ioc'
assert cfg['ProjectManager.CoupleFile'] == 'true'
assert cfg['board'] == 'NUCLEO-G474RE'
for pin, index in [('PB0', 0), ('PC1', 1), ('PC2', 2), ('PC3', 3), ('PC4', 4)]:
    assert cfg[pin + '.Signal'] == 'GPXTI' + str(index)
    assert cfg[pin + '.GPIO_ModeDefaultEXTI'] == 'GPIO_MODE_IT_RISING_FALLING'
    assert cfg[pin + '.GPIO_PuPd'] == 'GPIO_PULLDOWN'
    assert cfg[f'NVIC.EXTI{index}_IRQn'].startswith('true\\:7\\:0')
for index in [6, 7, 16]:
    assert cfg[f'TIM{index}.Prescaler'] == '170-1'
    assert cfg[f'TIM{index}.PeriodNoDither'] == '10000-1'
assert cfg['TIM7.OnePulseMode'] == 'TIM_OPMODE_SINGLE'
for apb in ['1', '2']:
    assert cfg[f'RCC.APB{apb}TimFreq_Value'] == '170000000'
tim = (project / 'Core/Src/tim.c').read_text()
assert 'SET_BIT(htim7.Instance->CR1, TIM_CR1_OPM)' in tim
assert 'htim16.Instance->CR1, TIM_CR1_OPM' not in tim
assert tim.count('Init.Prescaler = 170-1') == 3
assert tim.count('Init.Period = 9999') == 3
main = (project / 'Core/Src/main.c').read_text()
assert '#define MODO_TESTE_ATIVIDADE 21' in main
callbacks = ['HAL_GPIO_EXTI_Callback', 'HAL_TIM_PeriodElapsedCallback']
events = ['vButtonsEventCallback' + suffix for suffix in
          ['PressedEvent', 'ReleasedEvent', '500msPressedEvent', '3sPressedEvent']]
sources = list((project / 'Core/Src').glob('*.c'))
for callback in callbacks + events:
    strong, weak = [], []
    pattern = rf'^(__weak\s+)?void\s+{callback}\s*\('
    for source in sources:
        for match in re.finditer(pattern, source.read_text(), re.M):
            (weak if match[1] else strong).append(source.name)
    assert strong == ['main.c'], (callback, strong)
    if callback in events:
        assert weak == ['buttonsEvents.c'], (callback, weak)
for pointer in ['pTimerMatrixKeyboard', 'pTimerButtonsEventsDebouncing',
                'pTimerButtonsEventsLongPress']:
    assert f'htim == {pointer}' in main
isr = (project / 'Core/Src/stm32g4xx_it.c').read_text()
startup = (project / 'Core/Startup/startup_stm32g474retx.s').read_text()
for irq in ['EXTI0', 'EXTI1', 'EXTI2', 'EXTI3', 'EXTI4', 'TIM6_DAC',
            'TIM7_DAC', 'TIM1_UP_TIM16']:
    symbol = irq + '_IRQHandler'
    assert isr.count('void ' + symbol + '(void)') == 1
    assert symbol in startup
library = (project / 'Core/Src/buttonsEvents.c').read_text()
assert 'HAL_Delay(' not in library
for file in ['Core/Src/buttonsEvents.c', 'Core/Inc/buttonsEvents.h',
             'Core/Src/tim.c', 'Core/Src/gpio.c', 'Core/Src/usart.c',
             'Core/Inc/tim.h', 'Core/Inc/gpio.h', 'Core/Inc/usart.h',
             'Core/Src/main.c', 'Core/Src/matrixKeyboard.c',
             'Core/Inc/matrixKeyboard.h']:
    text = (project / file).read_text()
    assert all(len(line) <= 80 for line in text.splitlines()), file
    assert all(tag in text for tag in ['@file', '@brief', '@author',
                                     '@date', '@version']), file
    assert '\t' not in text, file
    if file.endswith('.h'):
        guard = Path(file).stem.upper() + '_H'
        assert f'#ifndef {guard}' in text and f'#define {guard}' in text, file
    # Check the documentation of application functions and declarations.
    pattern = (r'(?m)^(?:static\s+|__weak\s+)?'
               r'(void|int|teclado\*)\s*(\w+)\(([^;]*?)\)\s*([;{])')
    for match in re.finditer(pattern, text):
        result_type, function, parameters, terminator = match.groups()
        if file.endswith('.c') and terminator == ';':
            continue  # Generated forward declarations are kept as received.
        prefix = text[:match.start()].rstrip()
        begin = prefix.rfind('/**')
        end = prefix.rfind('*/')
        assert begin >= 0 and end > begin, (file, function, 'Doxygen')
        assert not prefix[end + 2:].strip(), (file, function, 'detached comment')
        doc = prefix[begin:end]
        assert '@brief' in doc, (file, function, '@brief')
        if parameters.strip() not in ['', 'void']:
            for parameter in parameters.split(','):
                name_match = re.search(r'(\w+)\s*$', parameter.strip())
                assert name_match, (file, function, parameter)
                param = name_match[1]
                assert re.search(r'@param\s+' + re.escape(param) + r'\b', doc), (
                    file, function, param)
        if result_type != 'void':
            assert '@return' in doc, (file, function, '@return')
if args.base:
    files = [p for p in (args.base / 'Drivers').rglob('*') if p.is_file()]
    for file in files:
        assert file.read_bytes() == (project / file.relative_to(args.base)).read_bytes()
    print(f'PASS: {len(files)} arquivos Drivers idênticos à base')
if args.elf:
    nm = shutil.which('arm-none-eabi-nm')
    assert nm, 'arm-none-eabi-nm must be on PATH'
    result = subprocess.check_output([nm, '--defined-only', str(args.elf)], text=True)
    symbols = {}
    for line in result.splitlines():
        fields = line.split()
        if len(fields) == 3:
            symbols[fields[2]] = fields[1]
    for symbol in callbacks + events + ['TIM7_DAC_IRQHandler',
                                       'TIM1_UP_TIM16_IRQHandler']:
        assert symbols.get(symbol) == 'T', (symbol, symbols.get(symbol))
    assert not subprocess.check_output([nm, '--undefined-only', str(args.elf)])
    print('PASS: callbacks e IRQs fortes no ELF; nenhum símbolo indefinido')
print('PASS: metadados XML, GPIO/NVIC/timers, API, dispatcher e padrão novo')
print('PENDENTE: abrir/regenerar IOC no CubeMX e medir os periféricos na placa')
