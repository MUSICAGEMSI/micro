#!/usr/bin/env python3
"""Package the editable project, tests, docs and deliberate firmware outputs."""
import hashlib
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
target = root / 'ES680_Aula21_GrupoB2_ENTREGA.zip'
files = []
for folder in ['Aula_21_Grupo_B2', 'tests', 'tools', 'evidencias', 'binarios']:
    for path in (root / folder).rglob('*'):
        if path.is_file() and not any(part in ['__pycache__', 'Debug', 'Release']
                                      for part in path.parts):
            files.append(path)
files.extend(root.glob('*.md'))
files = sorted(set(files))
assert any(p.name == '.project' for p in files)
assert any(p.name == 'buttonsEvents.c' for p in files)
assert not any(p.suffix in ['.o', '.pyc', '.deb'] for p in files)
manifest = '\n'.join(hashlib.sha256(path.read_bytes()).hexdigest() + '  ' +
                     path.relative_to(root).as_posix() for path in files) + '\n'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.relative_to(root))
    archive.writestr('MANIFESTO_ENTREGA_SHA256.txt', manifest)
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    for line in archive.read('MANIFESTO_ENTREGA_SHA256.txt').decode().splitlines():
        digest, name = line.split('  ', 1)
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
print(f'ZIP verificado: {len(files)} arquivos + manifesto; {target.stat().st_size} bytes')
print(target)
