#!/usr/bin/env python3
"""Build an unchanged STM32G474 CubeIDE C project outside its source tree."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
import shutil
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('project', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
project = args.project.resolve(strict=True)
output = args.output.resolve()
if output == project or project in output.parents:
    parser.error('Output must be outside the source project')
output.mkdir(parents=True, exist_ok=True)
compiler = shutil.which('arm-none-eabi-gcc')
if compiler is None:
    parser.error('arm-none-eabi-gcc must be on PATH')
toolbin = Path(compiler).resolve().parent
gcc = str(toolbin / 'arm-none-eabi-gcc')
environment = dict(os.environ, PATH=str(toolbin) + os.pathsep + os.environ['PATH'])
root = ET.parse(project / '.cproject').getroot()
debug = next(c for c in root.iter('configuration') if c.get('name') == 'Debug')
definitions, includes = [], []
for option in debug.iter('option'):
    kind = option.get('superClass', '')
    values = [v.get('value') for v in option.findall('listOptionValue')]
    if kind.endswith('tool.c.compiler.option.definedsymbols'):
        definitions.extend('-D' + value for value in values)
    if kind.endswith('tool.c.compiler.option.includepaths'):
        for value in values:
            if not value.startswith('../'):
                raise ValueError('Unsupported CubeIDE include: ' + value)
            includes.extend(['-I', str(project / value[3:])])
sources = sorted(p for folder in ['Core', 'Drivers']
                 for p in (project / folder).rglob('*')
                 if p.suffix in ['.c', '.s', '.S'])
if not definitions or not includes or not sources:
    raise ValueError('Missing CubeIDE definitions/includes or source files')
cpu = ['-mcpu=cortex-m4', '-mthumb', '-mfpu=fpv4-sp-d16', '-mfloat-abi=hard']
common = cpu + ['-std=gnu11', '-g3', '-O0', '-Wall', '-ffunction-sections',
                '-fdata-sections', '--specs=nano.specs'] + definitions + includes
commands = []
objects = []
for source in sources:
    obj = output / source.relative_to(project).with_suffix(source.suffix + '.o')
    obj.parent.mkdir(parents=True, exist_ok=True)
    command = [gcc] + common
    if source.suffix in ['.s', '.S']:
        command += ['-x', 'assembler-with-cpp']
    command += ['-c', str(source), '-o', str(obj)]
    commands.append({'directory': str(project), 'file': str(source),
                     'arguments': command})
    objects.append(str(obj))
(output / 'compile_commands.json').write_text(json.dumps(commands, indent=2))
def compile_source(entry):
    result = subprocess.run(entry['arguments'], env=environment,
                            text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT)
    if result.stdout:
        print(result.stdout, end='', flush=True)
    result.check_returncode()
with ThreadPoolExecutor(max_workers=min(4, os.cpu_count() or 1)) as executor:
    list(executor.map(compile_source, commands))
elf = output / (project.name + '.elf')
subprocess.run([gcc] + cpu + objects + ['-T', str(project / 'STM32G474RETX_FLASH.ld'),
    '--specs=nano.specs', '--specs=nosys.specs', '-static',
    '-Wl,--gc-sections', '-Wl,-Map=' + str(elf.with_suffix('.map')),
    '-Wl,--start-group', '-lc', '-lm', '-Wl,--end-group', '-o', str(elf)],
    env=environment, check=True)
for fmt, suffix in [('ihex', '.hex'), ('binary', '.bin')]:
    subprocess.run([str(toolbin / 'arm-none-eabi-objcopy'), '-O', fmt,
                    str(elf), str(elf.with_suffix(suffix))], check=True)
subprocess.run([str(toolbin / 'arm-none-eabi-size'), str(elf)], check=True)
print(f'Built {len(sources)} translation units: {elf}')
