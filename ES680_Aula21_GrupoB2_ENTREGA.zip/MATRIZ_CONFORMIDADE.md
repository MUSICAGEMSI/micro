# Matriz de conformidade — firmware entregue

Evidências referem-se a código, build e HAL simulada. Nenhum requisito
foi validado fisicamente. CubeMX/CubeIDE permanecem pendentes.

| ID | Requisito / fonte | Arquivo:linha | Estado real | Evidência |
|---|---|---|---|---|
| R01 | Biblioteca .h/.c; Aula21 p7 | `Core/Inc/buttonsEvents.h:8` | Implementado/compilado | API + build |
| R02 | Regras Aula4 no código novo; Aula4 p5–18 | `Core/Src/buttonsEvents.c:2` | Revisado; exceções documentadas | checkProject + REVISAO_PADRONIZACAO.md |
| R03 | Configuração via CubeMX; Aula21 p7 | `Aula_21_Grupo_B2.ioc:193` | PENDENTE ferramenta | IOC manual; C compilado |
| R04 | PC1/2/3/4, PB0; Aula21 p6 | `Core/Src/buttonsEvents.c:35` | Implementado/compilado | 50 cenários |
| R05 | Ambas bordas com debounce; Aula21 p14 / teoria29–31 | `Core/Src/gpio.c:74` | Lógica aprovada | bounce e transições |
| R06 | Init com dois handles; Aula21 p8 | `Core/Inc/buttonsEvents.h:34` | Implementado/compilado | API + símbolos |
| R07 | TIM7 debounce; Aula21 p10 | `Core/Src/main.c:115` | Implementado/compilado | dispatcher e janela |
| R08 | TIM16 duração; Aula21 p10 | `Core/Src/main.c:115` | Implementado/compilado | 59 cenários |
| R09 | TIM7 10ms one-pulse; Teoria20 p30 | `Core/Src/tim.c:90` | C compilado; físico pendente | PSC/ARR/OPM auditados |
| R10 | TIM16 10ms periódico; Teoria20 p34–36 | `Core/Src/tim.c:108` | C compilado; físico pendente | ticks simulados |
| R11 | Máscara individual/pending; Aula21 p11 | `Core/Src/buttonsEvents.c:140` | Lógica aprovada | bounce e rearme |
| R12 | Callback HAL única no main; Aula21 p12–13 | `Core/Src/main.c:228` | Compilado/auditado | nm T + contagem de definições |
| R13 | Coexistência TIM6/matriz; Aula21 p13 | `Core/Src/matrixKeyboard.c:32` | Lógica aprovada | varredura real com HAL mínima |
| R14 | Callback específica TIM7; Aula21 p13 | `Core/Src/buttonsEvents.c:165` | Implementado/compilado | debounce |
| R15 | Callback específica TIM16; Aula21 p13 | `Core/Src/buttonsEvents.c:213` | Implementado/compilado | temporização |
| R16 | Pressed weak/strong; Aula21 p14 | `Core/Src/buttonsEvents.c:250` | Compilado/lógica aprovada | nm + cinco botões |
| R17 | Released weak/strong; Aula21 p15 | `Core/Src/buttonsEvents.c:259` | Compilado/lógica aprovada | nm + cinco botões |
| R18 | 500ms weak/strong; Aula21 p16 | `Core/Src/buttonsEvents.c:268` | Compilado/lógica aprovada | nm + 50/100/... ticks |
| R19 | 3s weak/strong; Aula21 p17 | `Core/Src/buttonsEvents.c:277` | Compilado/lógica aprovada | 299/300 e rearme |
| R20 | Cima +1 Pressed/500ms; Aula21 p18 | `Core/Src/main.c:350` | Lógica aprovada | contagens e LEDs |
| R21 | Baixo -1 Pressed/500ms; Aula21 p18 | `Core/Src/main.c:353` | Lógica aprovada | contagens e LEDs |
| R22 | Enter zera em 3s; Aula21 p18 | `Core/Src/main.c:412` | Lógica aprovada | 2,9s/3,1s nominais |
| R23 | 4 LEDs binários; Aula21 p18 | `Core/Src/main.c:68` | Lógica aprovada | mapa das quatro saídas; físico pendente |
| R24 | Módulo 16; Decisão grupo | `Core/Src/main.c:351` | Lógica aprovada | 15+1 / 0-1 |
| R25 | Janela/estados compartilhados; Teoria20 p31 | `Core/Src/buttonsEvents.c:43` | Lógica aprovada | dois botões, reinício comum |
| R26 | 3s único por pressão; Aula18 p15 | `Core/Src/buttonsEvents.c:238` | Lógica aprovada | 70000 ticks e novo clique |
| R27 | Legado sem interferir LEDs; Compatibilidade Aula18 | `Core/Src/main.c:36` | Lógica aprovada | callbacks e matriz reais |
| R28 | PC13 não substitui botões; Aula21 p5–6 | `Core/Src/buttonsEvents.c:35` | Lógica aprovada | PC13 ignorado |
| R29 | ZIP de projeto completo; Aula21 p19 | `Aula_21_Grupo_B2.ioc:210` | Empacotado; importação PENDENTE | XML/manifesto; CubeIDE ausente |
| R30 | Relatório/manual de placa; Solicitação grupo | `Core/Src/main.c:49` | Documentado; físico PENDENTE | relatório 12 etapas; T01–T16 |
| R31 | Quatro eventos em todos; Aula21 p14–17 | `Core/Src/buttonsEvents.c:77` | Lógica aprovada | 5 x 10 durações |
| R32 | 500ms após 3s e ambos em 3000; Contrato V2 | `Core/Src/buttonsEvents.c:234` | Lógica aprovada | ordem instrumentada, tick350 |
| R33 | t0 após debounce; Decisão grupo | `Core/Src/buttonsEvents.c:195` | Lógica aprovada | sem evento antes de TIM7 |
| R34 | Released/Esquerda/Direita sem ação; Aula21 p18 | `Core/Src/main.c:356` | Lógica aprovada | 50 cenários e saídas |

A auditoria sintática de IOC/C não substitui o gerador CubeMX.
