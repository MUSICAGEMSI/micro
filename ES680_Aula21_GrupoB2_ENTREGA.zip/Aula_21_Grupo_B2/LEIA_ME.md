# ES680 — Aula 21 / Grupo B2

Os cinco push-buttons controlam o contador de quatro LEDs da Aula 21.
TIM6 e a biblioteca original da matriz estão integrados conforme o slide 13.
O teclado não controla os LEDs. Não há modos de demonstração antigos,
UART ou uso de PC13/PA5.

## Funcionamento e configuração

Cima soma 1 no Pressed e a cada 500 ms; Baixo subtrai nos mesmos eventos.
Enter zera em 3 s. Esquerda/Direita geram os quatro eventos sem alterar
o contador; Released também não altera os LEDs. O ciclo 0–15 foi mantido.

| Função | GPIO |
|---|---|
| Cima / Baixo / Esquerda / Direita | PC1 / PC2 / PC3 / PC4 |
| Enter | PB0 |
| LEDs de valor 8 / 4 / 2 / 1 | PA4 / PB14 / PA12 / PB5 |
| Linhas 1 / 2 / 3 / 4 da matriz | PB15 / PB13 / PB12 / PB11 |
| Colunas 1 / 2 / 3 / 4 da matriz | PA10 / PC9 / PC8 / PC7 |

Botões em EXTI0–4, ambas as bordas, pull-down; linhas da matriz como
entradas pull-down, colunas e LEDs como saídas. PA13/PA14 reservados ao SWD.

| Timer | Uso | Modo |
|---|---|---|
| TIM6 | leitura original do teclado | periódico |
| TIM7 | debounce dos cinco botões | one-pulse |
| TIM16 | eventos de 500 ms e 3 s | periódico |

Os três períodos são 10 ms: clock de 170 MHz, PSC=169 e ARR=9999.
EXTI0–4 e os três timers usam preempção 7/subprioridade 0. A callback HAL
única compara o handle com os três ponteiros preenchidos nas funções Init.

## Correções desta revisão

| Arquivos | Alteração / justificativa |
|---|---|
| matrixKeyboard.c/.h | Original v1.1 recuperado; ponteiro TIM6 e wrapper para a leitura existente. Slide 13. |
| main.c | Inicialização do teclado e terceira rota na callback HAL única. Slides 12–13. |
| tim.c/.h, stm32g4xx_it.c/.h | TIM6 de 10 ms, clock, NVIC e handler restaurados. Slide 13. |
| gpio.c/.h, .ioc | GPIOs da matriz restaurados junto dos botões e LEDs. Slides 7 e 13. |
| .mxproject | Lista de fontes atualizada. |
| matrixKeyboard.c/.h | Descrições de funções e globais organizadas conforme Aula 4; nomes e algoritmo preservados. |

O Init limpa a flag de update gerada na configuração, evitando antecipar
o primeiro período. As callbacks do teclado continuam fracas e sem ação
nos LEDs. Drivers e buttonsEvents.c/.h não foram alterados.

## Contagem de tempo — Aula 20, slides 34–36

Foi preservado o uso dos estados confirmados pelo TIM7. TIM16 começa
com a primeira pressão confirmada e para na última soltura confirmada.
Assim, repiques não alteram a duração antes do debounce das duas bordas
(Aula 20, slides 29–31; Aula 21, slide 14). A referência dos 500 ms e 3 s
é o Pressed confirmado, não a primeira borda bruta: há a janela de debounce
e a resolução de 10 ms. Não se afirma igualdade exata dos instantes.

## CubeIDE / CubeMX

1. Extraia e importe Aula_21_Grupo_B2 por File > Import > General >
   Existing Projects into Workspace. MCU: STM32G474RETx; FW_G4 V1.5.2.
2. Faça uma cópia antes de regenerar. Abra Aula_21_Grupo_B2.ioc; confira
   os GPIOs da tabela, EXTI nas duas bordas, os três períodos de 10 ms,
   TIM6/TIM16 periódicos e TIM7 one-pulse (VP_TIM7_VS_OPM/OPM_bit).
3. Confira NVIC TIM6_DAC, TIM7_DAC e TIM1_UP_TIM16 em prioridade 7.
   Gere com Keep User Code e arquivos separados por periférico.
4. Confira as três inicializações e a callback única; execute
   Project > Clean e Build Project.

CubeMX/CubeIDE estão ausentes aqui. A conferência do IOC com o C foi
estática; abrir, validar e regenerar na ferramenta continua PENDENTE.

## Validação

Build ARM GCC 14.2.1 aprovado sem avisos. Passaram os 59 cenários anteriores
dos botões e dois de integração da biblioteca matricial: 61 no total, com
HAL de testes. Leitura, estruturas e nomes originais foram conferidos.
O teste simultâneo confirma que o teclado não muda o contador dos botões.
Não houve teste físico.

Na placa: clique/repetição Cima/Baixo, Enter por 2,9 s e 3,1 s em pressões
separadas, eventos de Esquerda/Direita, dois push-buttons próximos e novo
clique após soltar. Teste uma tecla da matriz por vez sem alterar os LEDs.
Breakpoints suspendem a contagem e não medem os tempos reais.
