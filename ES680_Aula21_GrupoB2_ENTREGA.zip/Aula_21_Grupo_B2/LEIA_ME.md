# ES680 — Aula 21 / Grupo B2

Projeto dedicado aos cinco botões e ao contador de quatro LEDs da Aula 21.
A Aula 20 fundamenta o EXTI, o debounce e a medição do tempo de pressão.
O padrão de escrita segue a Aula 4, indicada pelo enunciado da Aula 21.

Não há modos de outros laboratórios, teclado matricial, TIM6, UART,
uso do botão PC13 ou do LED PA5. As dependências ST em Drivers são originais.

## Funcionamento

- Cima: soma 1 ao pressionar e a cada 500 ms enquanto estiver pressionado.
- Baixo: subtrai 1 nos mesmos eventos.
- Enter: zera o contador quando completa 3 s de pressão.
- Esquerda e Direita: geram os quatro eventos, sem alterar os LEDs.
- Soltar um botão não altera o contador.

O contador usa valores de 0 a 15: depois de 15 vem 0; antes de 0 vem 15.
Essa escolha permite representar o valor somente nos quatro LEDs.

## Pinos e timers

| Função | GPIO | Uso |
|---|---|---|
| Cima | PC1 | EXTI1 |
| Baixo | PC2 | EXTI2 |
| Esquerda | PC3 | EXTI3 |
| Direita | PC4 | EXTI4 |
| Enter | PB0 | EXTI0 |
| LED amarelo | PA4 | bit 3, valor 8 |
| LED vermelho | PB14 | bit 2, valor 4 |
| LED verde | PA12 | bit 1, valor 2 |
| LED azul | PB5 | bit 0, valor 1 |

Os botões são ativos em nível alto e usam pull-down. As interrupções
detectam as duas bordas. Os LEDs são saídas, iniciadas em nível baixo.
PA13 e PA14 ficam reservados à depuração SWD.

| Timer | Configuração | Função |
|---|---|---|
| TIM7 | 10 ms, one-pulse | confirmar a mudança de estado dos botões |
| TIM16 | 10 ms, periódico | gerar os eventos de 500 ms e 3 s |

Clock: HSI 16 MHz / 4 × 85 / 2 = 170 MHz. AHB, APB1 e APB2 sem divisão.
PSC = 169 e ARR = 9999: (169 + 1) × (9999 + 1) / 170 MHz = 10 ms.
EXTI0–4, TIM7_DAC e TIM1_UP_TIM16 usam preempção 7/subprioridade 0.
Assim, as rotinas que atualizam os botões não interrompem umas às outras.

## Organização

`buttonsEvents.c/.h` guarda os dois timers recebidos em Init e mantém uma
estrutura por botão. EXTI marca o botão e reinicia o TIM7 compartilhado.
Após 10 ms, a biblioteca lê o GPIO e chama Pressed ou Released somente
se o estado mudou. Limpa as flags antes da leitura e rearma a interrupção.

TIM16 conta apenas os estados confirmados pelo TIM7. Começa na primeira
pressão e para quando todos estão soltos. O tempo de 500 ms recomeça a
cada evento. O tempo de 3 s para em 3000 ms, impedindo outro evento de 3 s
até a soltura. Na marca de 3 s, 500 ms é chamado antes de 3 s; a repetição
de 500 ms continua depois. Outro botão não reinicia o tempo dos demais.
Um botão pressionado ao ligar também é confirmado pelo debounce.

`main.c` contém uma única callback HAL para os timers, conforme o modelo
dos slides 12–13. O slide 13 mostra a convivência com o teclado como
exemplo. Pelo escopo solicitado, esta entrega aplica o despacho apenas
ao TIM7 e ao TIM16; não entrega o laboratório do teclado.
Os nomes das funções e dos dois ponteiros dos botões foram preservados.

## Abrir e compilar no STM32CubeIDE

1. Extraia o ZIP e importe a pasta Aula_21_Grupo_B2 por
   File > Import > General > Existing Projects into Workspace.
2. O projeto usa STM32G474RETx e STM32Cube FW_G4 V1.5.2.
3. Abra Aula_21_Grupo_B2.ioc. A geração está configurada para separar os
   periféricos em pares .c/.h e preservar USER CODE. TIM7 one-pulse aparece
   no sinal virtual VP_TIM7_VS_OPM, no modo OPM_bit.
4. Execute Project > Clean e Build Project. Se regenerar pelo CubeMX,
   preserve uma cópia e confira os cinco EXTI, os dois timers e o build.

O código de aplicação fica nos blocos USER CODE do main e na biblioteca
própria. GPIO, timers e handlers seguem a configuração descrita no .ioc.

## Verificação realizada e bancada

Build ARM GCC 14.2.1 aprovado, sem avisos emitidos. A biblioteca e as ações
reais do main passaram em 59 cenários com HAL de testes: todos os botões,
bounce, dois botões, fronteira de 3 s, repetição longa, soltura e novo clique.
Esses testes verificam a lógica, não o sinal elétrico ou o tempo na placa.

O .ioc foi revisado em relação ao C, ao mapa oficial de pinos e à sintaxe
OPM dos exemplos oficiais STM32CubeG4. CubeMX e CubeIDE não estão
disponíveis neste ambiente: abrir/regenerar pelo gerador ainda não foi
validado. Nenhum teste físico foi feito.

Na placa, conferir nesta ordem: zero ao ligar; clique Cima/Baixo; Cima por
1,2 s (três incrementos); Enter por 2,9 s (não zera) e 3,1 s (zera);
Esquerda/Direita sem efeito visual; repetição após 3 s; dois botões;
novo clique após soltar. Para conferir os quatro eventos, usar as callbacks
no debugger; interromper o núcleo altera as medições de tempo.
