/**
 * @file buttonsEvents.c
 * @brief Leitura dos cinco botões com debounce e eventos de pressão.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 2.0
 */
#include "buttonsEvents.h"

/** @brief Porta, pino e interrupção de cada botão. */
typedef struct
{
  GPIO_TypeDef *pPort;
  uint16_t usPin;
  IRQn_Type xIrq;
} buttonWiring_t;

/** @brief Estado e tempo de pressão de um botão. */
typedef struct
{
  GPIO_PinState xStable; // Último nível aceito após o debounce.
  uint8_t ucPending;     // Aguarda a leitura pelo TIM7.
  uint8_t ucBootHeld;    // Já estava pressionado ao ligar.
  uint8_t ucTicks500ms;  // Conta de 0 a 49 e recomeça.
  uint16_t usTicks3s;    // Conta até 300 interrupções de 10 ms.
  uint8_t uc3sSent;      // Evita repetir o evento de 3 s.
} buttonState_t;

#define BUTTONS_TICKS_500MS 50U
#define BUTTONS_TICKS_3S 300U

TIM_HandleTypeDef *pTimerButtonsEventsDebouncing = NULL;
TIM_HandleTypeDef *pTimerButtonsEventsLongPress = NULL;

static const buttonWiring_t xWiring[BUTTON_TOTAL] =
{
  {BT_CIMA_GPIO_Port, BT_CIMA_Pin, BT_CIMA_EXTI_IRQn},
  {BT_BAIXO_GPIO_Port, BT_BAIXO_Pin, BT_BAIXO_EXTI_IRQn},
  {BT_ESQUERDA_GPIO_Port, BT_ESQUERDA_Pin, BT_ESQUERDA_EXTI_IRQn},
  {BT_DIREITA_GPIO_Port, BT_DIREITA_Pin, BT_DIREITA_EXTI_IRQn},
  {BT_ENTER_GPIO_Port, BT_ENTER_Pin, BT_ENTER_EXTI_IRQn}
};
static buttonState_t xStates[BUTTON_TOTAL];
static uint8_t ucTimingActive;

/**
 * @brief Para o timer e deixa a contagem pronta para o próximo uso.
 * @param pTimer Ponteiro para o timer já configurado.
 */
static void vButtonsEventsStopTimer(TIM_HandleTypeDef *pTimer)
{
  if (HAL_TIM_Base_Stop_IT(pTimer) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_SET_COUNTER(pTimer, 0U);
  __HAL_TIM_CLEAR_FLAG(pTimer, TIM_FLAG_UPDATE);
}

/**
 * @brief Reinicia a contagem e habilita a interrupção do timer.
 * @param pTimer Ponteiro para o timer que será iniciado.
 */
static void vButtonsEventsStartTimer(TIM_HandleTypeDef *pTimer)
{
  vButtonsEventsStopTimer(pTimer);
  if (HAL_TIM_Base_Start_IT(pTimer) != HAL_OK)
  {
    Error_Handler();
  }
}

/** @brief Mantém o TIM16 ligado enquanto houver um botão pressionado. */
static void vButtonsEventsSyncLongTimer(void)
{
  uint8_t ucAnyPressed = 0U;
  for (uint8_t ucBt = 0U; ucBt < BUTTON_TOTAL; ucBt++)
  {
    if ((xStates[ucBt].xStable == GPIO_PIN_SET) &&
        (xStates[ucBt].ucBootHeld == 0U))
    {
      ucAnyPressed = 1U;
    }
  }
  if ((ucAnyPressed != 0U) && (ucTimingActive == 0U))
  {
    vButtonsEventsStartTimer(pTimerButtonsEventsLongPress);
    ucTimingActive = 1U;
  }
  else if ((ucAnyPressed == 0U) && (ucTimingActive != 0U))
  {
    vButtonsEventsStopTimer(pTimerButtonsEventsLongPress);
    ucTimingActive = 0U;
  }
}

/**
 * @brief Guarda os timers recebidos e lê o estado inicial dos botões.
 * @param pTimDebouncer TIM7, usado para os 10 ms de debounce.
 * @param pTimPressedTime TIM16, usado para medir o tempo de pressão.
 */
void vButtonsEventsInit(TIM_HandleTypeDef *pTimDebouncer,
                       TIM_HandleTypeDef *pTimPressedTime)
{
  uint32_t ulPrimask = __get_PRIMASK();

  if ((pTimDebouncer == NULL) || (pTimPressedTime == NULL) ||
      (pTimDebouncer == pTimPressedTime))
  {
    Error_Handler();
    return;
  }

  // Evita interrupções enquanto prepara o estado dos botões.
  __disable_irq();
  pTimerButtonsEventsDebouncing = pTimDebouncer;
  pTimerButtonsEventsLongPress = pTimPressedTime;
  vButtonsEventsStopTimer(pTimDebouncer);
  vButtonsEventsStopTimer(pTimPressedTime);
  ucTimingActive = 0U;

  for (uint8_t ucBt = 0U; ucBt < BUTTON_TOTAL; ucBt++)
  {
    __HAL_GPIO_EXTI_CLEAR_IT(xWiring[ucBt].usPin);
    HAL_NVIC_ClearPendingIRQ(xWiring[ucBt].xIrq);
    xStates[ucBt] = (buttonState_t){0};
    xStates[ucBt].xStable = HAL_GPIO_ReadPin(xWiring[ucBt].pPort,
                                           xWiring[ucBt].usPin);
    xStates[ucBt].ucBootHeld =
      (xStates[ucBt].xStable == GPIO_PIN_SET) ? 1U : 0U;
    HAL_NVIC_EnableIRQ(xWiring[ucBt].xIrq);
  }
  __set_PRIMASK(ulPrimask);
}

/**
 * @brief Inicia o debounce do botão que gerou a interrupção EXTI.
 * @param GPIO_Pin Pino informado pela callback da HAL.
 */
void vButtonsEventsExtiCallback(uint16_t GPIO_Pin)
{
  if (pTimerButtonsEventsDebouncing == NULL)
  {
    return;
  }
  for (uint8_t ucBt = 0U; ucBt < BUTTON_TOTAL; ucBt++)
  {
    if (GPIO_Pin == xWiring[ucBt].usPin)
    {
      HAL_NVIC_DisableIRQ(xWiring[ucBt].xIrq);
      __HAL_GPIO_EXTI_CLEAR_IT(GPIO_Pin);
      HAL_NVIC_ClearPendingIRQ(xWiring[ucBt].xIrq);
      xStates[ucBt].ucPending = 1U;
      // Se outro botão mudar, reinicia os 10 ms para conferir ambos.
      vButtonsEventsStartTimer(pTimerButtonsEventsDebouncing);
      return;
    }
  }
}

/**
 * @brief Confere se o botão mudou de estado após os 10 ms de debounce.
 * @note EXTI, TIM7 e TIM16 têm a mesma prioridade e não se interrompem.
 */
void vButtonsEventsDebouncingPeriodElapsedCallback(void)
{
  if (pTimerButtonsEventsDebouncing == NULL)
  {
    return;
  }
  vButtonsEventsStopTimer(pTimerButtonsEventsDebouncing);
  for (uint8_t ucBt = 0U; ucBt < BUTTON_TOTAL; ucBt++)
  {
    buttonState_t *pState = &xStates[ucBt];
    if (pState->ucPending != 0U)
    {
      GPIO_PinState xLevel;
      uint8_t ucWasBootHeld = pState->ucBootHeld;

      // Limpa as flags antes de ler. Uma nova borda poderá ser atendida.
      __HAL_GPIO_EXTI_CLEAR_IT(xWiring[ucBt].usPin);
      HAL_NVIC_ClearPendingIRQ(xWiring[ucBt].xIrq);
      xLevel = HAL_GPIO_ReadPin(xWiring[ucBt].pPort, xWiring[ucBt].usPin);
      pState->ucPending = 0U;
      HAL_NVIC_EnableIRQ(xWiring[ucBt].xIrq);

      if (xLevel != pState->xStable)
      {
        pState->xStable = xLevel;
        pState->ucTicks500ms = 0U;
        pState->usTicks3s = 0U;
        pState->uc3sSent = 0U;
        if (xLevel == GPIO_PIN_SET)
        {
          vButtonsEventCallbackPressedEvent((button_t)ucBt);
        }
        else
        {
          pState->ucBootHeld = 0U;
          // Se já estava pressionado ao ligar, espera a primeira soltura.
          if (ucWasBootHeld == 0U)
          {
            vButtonsEventCallbackReleasedEvent((button_t)ucBt);
          }
        }
      }
    }
  }
  vButtonsEventsSyncLongTimer();
}

/** @brief Soma 10 ms por botão e verifica os eventos de 500 ms e 3 s. */
void vButtonsEventsLongPressPeriodElapsedCallback(void)
{
  if (ucTimingActive == 0U)
  {
    return;
  }
  for (uint8_t ucBt = 0U; ucBt < BUTTON_TOTAL; ucBt++)
  {
    buttonState_t *pState = &xStates[ucBt];
    if ((pState->xStable == GPIO_PIN_SET) && (pState->ucBootHeld == 0U))
    {
      pState->ucTicks500ms++;
      if (pState->usTicks3s < BUTTONS_TICKS_3S)
      {
        pState->usTicks3s++;
      }
      if (pState->ucTicks500ms == BUTTONS_TICKS_500MS)
      {
        pState->ucTicks500ms = 0U;
        vButtonsEventCallback500msPressedEvent((button_t)ucBt);
      }
      // Aos 3 s, chama os dois eventos: primeiro 500 ms, depois 3 s.
      if ((pState->usTicks3s == BUTTONS_TICKS_3S) &&
          (pState->uc3sSent == 0U))
      {
        pState->uc3sSent = 1U;
        vButtonsEventCallback3sPressedEvent((button_t)ucBt);
      }
    }
  }
}

// As ações ficam no main.c. O __weak permite defini-las sem mudar a biblioteca.
/**
 * @brief Evento de botão pressionado após o debounce.
 * @param xBt Botão que foi pressionado.
 */
__weak void vButtonsEventCallbackPressedEvent(button_t xBt)
{
  UNUSED(xBt);
}

/**
 * @brief Evento de botão solto após o debounce.
 * @param xBt Botão que foi solto.
 */
__weak void vButtonsEventCallbackReleasedEvent(button_t xBt)
{
  UNUSED(xBt);
}

/**
 * @brief Evento repetido a cada 500 ms enquanto o botão estiver pressionado.
 * @param xBt Botão que continua pressionado.
 */
__weak void vButtonsEventCallback500msPressedEvent(button_t xBt)
{
  UNUSED(xBt);
}

/**
 * @brief Evento chamado uma vez ao completar 3 s de pressão.
 * @param xBt Botão que continua pressionado.
 */
__weak void vButtonsEventCallback3sPressedEvent(button_t xBt)
{
  UNUSED(xBt);
}
