/**
 * @file buttonsEvents.c
 * @brief Debounce e eventos dos cinco botões da Aula 21.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
#include "buttonsEvents.h"

typedef struct
{
  GPIO_TypeDef *pPorta;
  uint16_t usPino;
  IRQn_Type xIrq;
  GPIO_PinState xEstado;
  uint8_t ucPendente;
  uint16_t usTempo500ms;
  uint16_t usTempo3s;
} botao_t;

#define PERIODO_MS 10U
#define TEMPO_500_MS 500U
#define TEMPO_3_S 3000U

TIM_HandleTypeDef *pTimerButtonsEventsDebouncing = NULL;
TIM_HandleTypeDef *pTimerButtonsEventsLongPress = NULL;

static botao_t xBotoes[BUTTON_TOTAL] =
{
  {BT_CIMA_GPIO_Port, BT_CIMA_Pin, BT_CIMA_EXTI_IRQn,
   GPIO_PIN_RESET, 0U, 0U, 0U},
  {BT_BAIXO_GPIO_Port, BT_BAIXO_Pin, BT_BAIXO_EXTI_IRQn,
   GPIO_PIN_RESET, 0U, 0U, 0U},
  {BT_ESQUERDA_GPIO_Port, BT_ESQUERDA_Pin, BT_ESQUERDA_EXTI_IRQn,
   GPIO_PIN_RESET, 0U, 0U, 0U},
  {BT_DIREITA_GPIO_Port, BT_DIREITA_Pin, BT_DIREITA_EXTI_IRQn,
   GPIO_PIN_RESET, 0U, 0U, 0U},
  {BT_ENTER_GPIO_Port, BT_ENTER_Pin, BT_ENTER_EXTI_IRQn,
   GPIO_PIN_RESET, 0U, 0U, 0U}
};
static uint8_t ucTimerAtivo;

/**
 * @brief Para o timer e limpa a contagem e a flag de interrupção.
 * @param pTimer Timer que será parado.
 */
static void vButtonsEventsPararTimer(TIM_HandleTypeDef *pTimer)
{
  if (HAL_TIM_Base_Stop_IT(pTimer) != HAL_OK)
  {
    Error_Handler();
  }
  __HAL_TIM_SET_COUNTER(pTimer, 0U);
  __HAL_TIM_CLEAR_FLAG(pTimer, TIM_FLAG_UPDATE);
}

/**
 * @brief Inicia um novo período com interrupção.
 * @param pTimer Timer que será iniciado.
 */
static void vButtonsEventsReiniciarTimer(TIM_HandleTypeDef *pTimer)
{
  vButtonsEventsPararTimer(pTimer);
  if (HAL_TIM_Base_Start_IT(pTimer) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
 * @brief Guarda os timers recebidos e prepara o estado dos botões.
 * @param pTimDebouncer TIM7, usado para os 10 ms de debounce.
 * @param pTimPressedTime TIM16, usado para medir o tempo de pressão.
 */
void vButtonsEventsInit(TIM_HandleTypeDef *pTimDebouncer,
                       TIM_HandleTypeDef *pTimPressedTime)
{
  uint32_t ulPrimask = __get_PRIMASK();
  uint8_t ucDebounce = 0U;

  if ((pTimDebouncer == NULL) || (pTimPressedTime == NULL) ||
      (pTimDebouncer == pTimPressedTime))
  {
    Error_Handler();
    return;
  }

  __disable_irq();
  pTimerButtonsEventsDebouncing = pTimDebouncer;
  pTimerButtonsEventsLongPress = pTimPressedTime;
  vButtonsEventsPararTimer(pTimDebouncer);
  vButtonsEventsPararTimer(pTimPressedTime);
  ucTimerAtivo = 0U;

  for (uint8_t ucBotao = 0U; ucBotao < BUTTON_TOTAL; ucBotao++)
  {
    botao_t *pBotao = &xBotoes[ucBotao];
    __HAL_GPIO_EXTI_CLEAR_IT(pBotao->usPino);
    HAL_NVIC_ClearPendingIRQ(pBotao->xIrq);
    pBotao->xEstado = GPIO_PIN_RESET;
    pBotao->usTempo500ms = 0U;
    pBotao->usTempo3s = 0U;
    pBotao->ucPendente =
      (HAL_GPIO_ReadPin(pBotao->pPorta, pBotao->usPino) == GPIO_PIN_SET);
    ucDebounce |= pBotao->ucPendente;
    HAL_NVIC_EnableIRQ(pBotao->xIrq);
  }

  // Um botão pressionado ao ligar também passa pelos 10 ms de debounce.
  if (ucDebounce != 0U)
  {
    vButtonsEventsReiniciarTimer(pTimDebouncer);
  }
  __set_PRIMASK(ulPrimask);
}

/**
 * @brief Inicia o debounce do botão que gerou a interrupção EXTI.
 * @param GPIO_Pin Pino informado pela callback da HAL.
 */
void vButtonsEventsExtiCallback(uint16_t GPIO_Pin)
{
  if (pTimerButtonsEventsDebouncing == NULL)
  {
    return;
  }

  for (uint8_t ucBotao = 0U; ucBotao < BUTTON_TOTAL; ucBotao++)
  {
    botao_t *pBotao = &xBotoes[ucBotao];
    if (GPIO_Pin == pBotao->usPino)
    {
      HAL_NVIC_DisableIRQ(pBotao->xIrq);
      __HAL_GPIO_EXTI_CLEAR_IT(GPIO_Pin);
      HAL_NVIC_ClearPendingIRQ(pBotao->xIrq);
      pBotao->ucPendente = 1U;
      // Outro botão reinicia os 10 ms, sem apagar as pendências anteriores.
      vButtonsEventsReiniciarTimer(pTimerButtonsEventsDebouncing);
      return;
    }
  }
}

/** @brief Confirma as mudanças de estado quando o TIM7 termina os 10 ms. */
void vButtonsEventsDebouncingPeriodElapsedCallback(void)
{
  uint8_t ucPressionado = 0U;

  if (pTimerButtonsEventsDebouncing == NULL)
  {
    return;
  }
  vButtonsEventsPararTimer(pTimerButtonsEventsDebouncing);

  for (uint8_t ucBotao = 0U; ucBotao < BUTTON_TOTAL; ucBotao++)
  {
    botao_t *pBotao = &xBotoes[ucBotao];
    if (pBotao->ucPendente != 0U)
    {
      GPIO_PinState xNivel;

      // Limpa antes de ler para não apagar uma borda que ocorrer depois.
      __HAL_GPIO_EXTI_CLEAR_IT(pBotao->usPino);
      HAL_NVIC_ClearPendingIRQ(pBotao->xIrq);
      xNivel = HAL_GPIO_ReadPin(pBotao->pPorta, pBotao->usPino);
      pBotao->ucPendente = 0U;
      HAL_NVIC_EnableIRQ(pBotao->xIrq);

      if (xNivel != pBotao->xEstado)
      {
        pBotao->xEstado = xNivel;
        pBotao->usTempo500ms = 0U;
        pBotao->usTempo3s = 0U;
        if (xNivel == GPIO_PIN_SET)
        {
          vButtonsEventCallbackPressedEvent((button_t)ucBotao);
        }
        else
        {
          vButtonsEventCallbackReleasedEvent((button_t)ucBotao);
        }
      }
    }
    if (pBotao->xEstado == GPIO_PIN_SET)
    {
      ucPressionado = 1U;
    }
  }

  // O TIM16 só trabalha enquanto houver algum botão pressionado.
  if ((ucPressionado != 0U) && (ucTimerAtivo == 0U))
  {
    vButtonsEventsReiniciarTimer(pTimerButtonsEventsLongPress);
    ucTimerAtivo = 1U;
  }
  else if ((ucPressionado == 0U) && (ucTimerAtivo != 0U))
  {
    vButtonsEventsPararTimer(pTimerButtonsEventsLongPress);
    ucTimerAtivo = 0U;
  }
}

/** @brief Soma 10 ms por botão e verifica os eventos de 500 ms e 3 s. */
void vButtonsEventsLongPressPeriodElapsedCallback(void)
{
  if (ucTimerAtivo == 0U)
  {
    return;
  }

  for (uint8_t ucBotao = 0U; ucBotao < BUTTON_TOTAL; ucBotao++)
  {
    botao_t *pBotao = &xBotoes[ucBotao];
    if (pBotao->xEstado == GPIO_PIN_SET)
    {
      pBotao->usTempo500ms += PERIODO_MS;
      if (pBotao->usTempo500ms == TEMPO_500_MS)
      {
        pBotao->usTempo500ms = 0U;
        vButtonsEventCallback500msPressedEvent((button_t)ucBotao);
      }
      // Para em 3 s: só uma nova pressão permite chamar esse evento de novo.
      if (pBotao->usTempo3s < TEMPO_3_S)
      {
        pBotao->usTempo3s += PERIODO_MS;
        if (pBotao->usTempo3s == TEMPO_3_S)
        {
          vButtonsEventCallback3sPressedEvent((button_t)ucBotao);
        }
      }
    }
  }
}

// O main.c define as ações dos eventos, sem alterar esta biblioteca.
/**
 * @brief Evento de botão pressionado após o debounce.
 * @param xBt Botão que foi pressionado.
 */
__weak void vButtonsEventCallbackPressedEvent(button_t xBt)
{
  UNUSED(xBt);
}

/**
 * @brief Evento de botão solto após o debounce.
 * @param xBt Botão que foi solto.
 */
__weak void vButtonsEventCallbackReleasedEvent(button_t xBt)
{
  UNUSED(xBt);
}

/**
 * @brief Evento repetido a cada 500 ms enquanto o botão estiver pressionado.
 * @param xBt Botão que continua pressionado.
 */
__weak void vButtonsEventCallback500msPressedEvent(button_t xBt)
{
  UNUSED(xBt);
}

/**
 * @brief Evento chamado uma vez ao completar 3 s de pressão.
 * @param xBt Botão que continua pressionado.
 */
__weak void vButtonsEventCallback3sPressedEvent(button_t xBt)
{
  UNUSED(xBt);
}
