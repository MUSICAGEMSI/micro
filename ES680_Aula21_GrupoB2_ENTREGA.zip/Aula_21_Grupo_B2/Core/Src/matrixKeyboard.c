/**
 * @file    : matrixKeyboard.c
 * @brief   : Leitura multiplexada e eventos do teclado matricial 4x4.
 * @author  : nicolas
 * @date    : 12-Oct-2026
 * @version : 2.0
 * @note    : Comentários revisados por Codex em 03-Nov-2026.
 */

#include "matrixKeyboard.h"

teclado xTeclado = {0};
TIM_HandleTypeDef *pTimerMatrixKeyboard = NULL;
static st_tecla_timer xTimers[KEY_TOTAL_NUM] = {0};
static uint8_t u8ColAtual = 0;

/**
 * @brief Permite consultar o estado das teclas lidas pelo TIM6.
 * @return Ponteiro para a estrutura com o estado de cada tecla.
 */
teclado* pMatrixKeyboardGetKeys(void)
{
  return &xTeclado;
}

/**
 * @brief Guarda o timer usado pelo teclado e inicia suas interrupções.
 * @param htim Ponteiro para o TIM6, configurado para 10 ms.
 */
void vMatrixKeyboardInit(TIM_HandleTypeDef *htim)
{
  pTimerMatrixKeyboard = htim;
  __HAL_TIM_CLEAR_FLAG(htim, TIM_FLAG_UPDATE);
  HAL_TIM_Base_Start_IT(htim);
}

/**
 * @brief Atualiza o tempo de uma tecla e chama os eventos de 500 ms e 3 s.
 * @param eBotao Tecla que está sendo verificada.
 * @param u8Pressionado Indica se a tecla continua pressionada.
 */
static void vProcessaTempoBotao(enum_teclado eBotao, uint8_t u8Pressionado)
{
  if (u8Pressionado)
  {
    // Cada chamada corresponde a uma interrupção de 10 ms do TIM6.
    xTimers[eBotao].u16TempoPress500ms += 10;
    xTimers[eBotao].u16TempoPress3s += 10;

    // Evento periódico de 500 ms
    if (xTimers[eBotao].u16TempoPress500ms >= 500)
    {
      // Recomeça para repetir o evento enquanto a tecla estiver pressionada.
      xTimers[eBotao].u16TempoPress500ms = 0;
      vMatrixKeyboard500msPressedCallback(eBotao);
    }

    // Evento de 3 segundos (3000 ms) - dispara uma vez por pressão
    if (xTimers[eBotao].u16TempoPress3s >= 3000)
    {
      if (xTimers[eBotao].u8Evento3sDisparado == 0)
      {
        // Só permite outro evento de 3 s depois que a tecla for solta.
        xTimers[eBotao].u8Evento3sDisparado = 1;
        vMatrixKeyboardThreeSecPressedCallback(eBotao);
      }
    }
  }
  else
  {
    // Ao soltar, prepara os contadores para uma nova pressão.
    xTimers[eBotao].u16TempoPress500ms = 0;
    xTimers[eBotao].u16TempoPress3s = 0;
    xTimers[eBotao].u8Evento3sDisparado = 0;
  }
}

/** @brief Alimenta uma coluna por vez e lê as quatro linhas do teclado. */
void vMatrixKeyboardCallback(void)
{
  if (u8ColAtual == 0)
  {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_SET);

    // Lê as quatro linhas com apenas esta coluna em nível alto.
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_15) == 1)
    {
      xTeclado.b1 = 1;
    }
    else
    {
      xTeclado.b1 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_13) == 1)
    {
      xTeclado.b4 = 1;
    }
    else
    {
      xTeclado.b4 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12) == 1)
    {
      xTeclado.b7 = 1;
    }
    else
    {
      xTeclado.b7 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == 1)
    {
      xTeclado.bEstrela = 1;
    }
    else
    {
      xTeclado.bEstrela = 0;
    }
  }

  if (u8ColAtual == 1)
  {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET);

    // Lê as quatro linhas com apenas esta coluna em nível alto.
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_15) == 1)
    {
      xTeclado.b2 = 1;
    }
    else
    {
      xTeclado.b2 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_13) == 1)
    {
      xTeclado.b5 = 1;
    }
    else
    {
      xTeclado.b5 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12) == 1)
    {
      xTeclado.b8 = 1;
    }
    else
    {
      xTeclado.b8 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == 1)
    {
      xTeclado.b0 = 1;
    }
    else
    {
      xTeclado.b0 = 0;
    }
  }

  if (u8ColAtual == 2)
  {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_SET);

    // Lê as quatro linhas com apenas esta coluna em nível alto.
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_15) == 1)
    {
      xTeclado.b3 = 1;
    }
    else
    {
      xTeclado.b3 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_13) == 1)
    {
      xTeclado.b6 = 1;
    }
    else
    {
      xTeclado.b6 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12) == 1)
    {
      xTeclado.b9 = 1;
    }
    else
    {
      xTeclado.b9 = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == 1)
    {
      xTeclado.bHash = 1;
    }
    else
    {
      xTeclado.bHash = 0;
    }
  }

  if (u8ColAtual == 3)
  {
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);

    // Lê as quatro linhas com apenas esta coluna em nível alto.
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_15) == 1)
    {
      xTeclado.ba = 1;
    }
    else
    {
      xTeclado.ba = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_13) == 1)
    {
      xTeclado.bb = 1;
    }
    else
    {
      xTeclado.bb = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12) == 1)
    {
      xTeclado.bc = 1;
    }
    else
    {
      xTeclado.bc = 0;
    }

    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11) == 1)
    {
      xTeclado.bd = 1;
    }
    else
    {
      xTeclado.bd = 0;
    }
  }

  if (u8ColAtual == 3)
  {
    u8ColAtual = 0;
  }
  else
  {
    u8ColAtual++;
  }

  // Usa os estados lidos para atualizar o tempo de cada tecla.
  vProcessaTempoBotao(KEY_1, xTeclado.b1);
  vProcessaTempoBotao(KEY_2, xTeclado.b2);
  vProcessaTempoBotao(KEY_3, xTeclado.b3);
  vProcessaTempoBotao(KEY_A, xTeclado.ba);
  vProcessaTempoBotao(KEY_4, xTeclado.b4);
  vProcessaTempoBotao(KEY_5, xTeclado.b5);
  vProcessaTempoBotao(KEY_6, xTeclado.b6);
  vProcessaTempoBotao(KEY_B, xTeclado.bb);
  vProcessaTempoBotao(KEY_7, xTeclado.b7);
  vProcessaTempoBotao(KEY_8, xTeclado.b8);
  vProcessaTempoBotao(KEY_9, xTeclado.b9);
  vProcessaTempoBotao(KEY_C, xTeclado.bc);
  vProcessaTempoBotao(KEY_ESTRELA, xTeclado.bEstrela);
  vProcessaTempoBotao(KEY_0, xTeclado.b0);
  vProcessaTempoBotao(KEY_HASH, xTeclado.bHash);
  vProcessaTempoBotao(KEY_D, xTeclado.bd);
}

/**
 * @brief Evento repetido a cada 500 ms; a ação é definida no main.c.
 * @param xButton Tecla que continua pressionada.
 */
__weak void vMatrixKeyboard500msPressedCallback(enum_teclado xButton)
{
  UNUSED(xButton);
}

/**
 * @brief Evento de 3 s; a ação é definida no main.c.
 * @param xButton Tecla que completou 3 s pressionada.
 */
__weak void vMatrixKeyboardThreeSecPressedCallback(enum_teclado xButton)
{
  UNUSED(xButton);
}

/**
 * @brief Recebe a interrupção do TIM6 e chama a leitura do teclado.
 */
void vMatrixKeyboardPeriodElapsedCallback(void)
{
  vMatrixKeyboardCallback();
}
