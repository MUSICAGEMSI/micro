/**
 * @file tim.c
 * @brief Configuração dos timers do teclado e dos botões.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 2.0
 * @note Configuração adaptada manualmente; CubeMX ainda não executado.
 */
#include "tim.h"

TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim16;

// Com clock de 170 MHz, prescaler 169 e período 9999 resultam em 10 ms.

/** @brief Configura o TIM6 para a leitura periódica do teclado. */
void MX_TIM6_Init(void)
{
  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */

  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 170-1;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 9999;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;

  if (HAL_TIMEx_MasterConfigSynchronization(&htim6,
                                            &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */
}

/** @brief Configura o TIM7 para os 10 ms de debounce dos botões. */
void MX_TIM7_Init(void)
{
  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */

  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 170-1;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 9999;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;

  if (HAL_TIMEx_MasterConfigSynchronization(&htim7,
                                            &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN TIM7_Init 2 */
  // One-pulse: o timer para sozinho quando termina os 10 ms.
  SET_BIT(htim7.Instance->CR1, TIM_CR1_OPM);

  /* USER CODE END TIM7_Init 2 */
}

/** @brief Configura o TIM16 para contar o tempo de pressão a cada 10 ms. */
void MX_TIM16_Init(void)
{
  /* USER CODE BEGIN TIM16_Init 0 */

  /* USER CODE END TIM16_Init 0 */


  /* USER CODE BEGIN TIM16_Init 1 */

  /* USER CODE END TIM16_Init 1 */

  htim16.Instance = TIM16;
  htim16.Init.Prescaler = 170-1;
  htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim16.Init.Period = 9999;
  htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

  if (HAL_TIM_Base_Init(&htim16) != HAL_OK)
  {
    Error_Handler();
  }



  /* USER CODE BEGIN TIM16_Init 2 */

  /* USER CODE END TIM16_Init 2 */
}

/**
 * @brief Habilita o clock e a interrupção do timer recebido.
 * @param htim_base Ponteiro para TIM6, TIM7 ou TIM16.
 */
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* htim_base)
{
  if (htim_base->Instance == TIM6)
  {
  /* USER CODE BEGIN TIM6_MspInit 0 */

  /* USER CODE END TIM6_MspInit 0 */
    // Habilita o clock e a interrupção do TIM6.
    __HAL_RCC_TIM6_CLK_ENABLE();
    HAL_NVIC_SetPriority(TIM6_DAC_IRQn, 7, 0);
    HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);
  /* USER CODE BEGIN TIM6_MspInit 1 */

  /* USER CODE END TIM6_MspInit 1 */
  }

  else if (htim_base->Instance == TIM7)
  {
    __HAL_RCC_TIM7_CLK_ENABLE();
    HAL_NVIC_SetPriority(TIM7_DAC_IRQn, 7, 0);
    HAL_NVIC_EnableIRQ(TIM7_DAC_IRQn);
  }
  else if (htim_base->Instance == TIM16)
  {
    __HAL_RCC_TIM16_CLK_ENABLE();
    HAL_NVIC_SetPriority(TIM1_UP_TIM16_IRQn, 7, 0);
    HAL_NVIC_EnableIRQ(TIM1_UP_TIM16_IRQn);
  }
}


/**
 * @brief Desliga o clock e a interrupção do timer recebido.
 * @param htim_base Ponteiro para TIM6, TIM7 ou TIM16.
 */
void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* htim_base)
{
  if (htim_base->Instance == TIM6)
  {
  /* USER CODE BEGIN TIM6_MspDeInit 0 */

  /* USER CODE END TIM6_MspDeInit 0 */
    // Desliga o TIM6 e sua interrupção.
    __HAL_RCC_TIM6_CLK_DISABLE();

    HAL_NVIC_DisableIRQ(TIM6_DAC_IRQn);
  /* USER CODE BEGIN TIM6_MspDeInit 1 */

  /* USER CODE END TIM6_MspDeInit 1 */
  }

  else if (htim_base->Instance == TIM7)
  {
    __HAL_RCC_TIM7_CLK_DISABLE();
    HAL_NVIC_DisableIRQ(TIM7_DAC_IRQn);
  }
  else if (htim_base->Instance == TIM16)
  {
    __HAL_RCC_TIM16_CLK_DISABLE();
    HAL_NVIC_DisableIRQ(TIM1_UP_TIM16_IRQn);
  }
}

