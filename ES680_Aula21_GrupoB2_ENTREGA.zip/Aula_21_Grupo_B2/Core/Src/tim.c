/**
 * @file tim.c
 * @brief TIM7 para debounce e TIM16 para o tempo de pressão.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
#include "tim.h"

TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim16;

// Com clock de 170 MHz, prescaler 169 e período 9999 resultam em 10 ms.

/** @brief Configura o TIM7 para encerrar a contagem após 10 ms. */
void MX_TIM7_Init(void)
{
  /* USER CODE BEGIN TIM7_Init 0 */
  /* USER CODE END TIM7_Init 0 */
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 169;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 9999;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_OnePulse_Init(&htim7, TIM_OPMODE_SINGLE) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM7_Init 2 */
  /* USER CODE END TIM7_Init 2 */
}

/** @brief Configura o TIM16 para gerar uma interrupção a cada 10 ms. */
void MX_TIM16_Init(void)
{
  /* USER CODE BEGIN TIM16_Init 0 */
  /* USER CODE END TIM16_Init 0 */
  htim16.Instance = TIM16;
  htim16.Init.Prescaler = 169;
  htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim16.Init.Period = 9999;
  htim16.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim16.Init.RepetitionCounter = 0;
  htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim16) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM16_Init 2 */
  /* USER CODE END TIM16_Init 2 */
}

/**
 * @brief Habilita o clock e a interrupção do timer recebido.
 * @param htim_base Ponteiro para TIM7 ou TIM16.
 */
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htim_base)
{
  if (htim_base->Instance == TIM7)
  {
    __HAL_RCC_TIM7_CLK_ENABLE();
    HAL_NVIC_SetPriority(TIM7_DAC_IRQn, 7, 0);
    HAL_NVIC_EnableIRQ(TIM7_DAC_IRQn);
  }
  else if (htim_base->Instance == TIM16)
  {
    __HAL_RCC_TIM16_CLK_ENABLE();
    HAL_NVIC_SetPriority(TIM1_UP_TIM16_IRQn, 7, 0);
    HAL_NVIC_EnableIRQ(TIM1_UP_TIM16_IRQn);
  }
}

/**
 * @brief Desliga o clock e a interrupção do timer recebido.
 * @param htim_base Ponteiro para TIM7 ou TIM16.
 */
void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef *htim_base)
{
  if (htim_base->Instance == TIM7)
  {
    __HAL_RCC_TIM7_CLK_DISABLE();
    HAL_NVIC_DisableIRQ(TIM7_DAC_IRQn);
  }
  else if (htim_base->Instance == TIM16)
  {
    __HAL_RCC_TIM16_CLK_DISABLE();
    HAL_NVIC_DisableIRQ(TIM1_UP_TIM16_IRQn);
  }
}

