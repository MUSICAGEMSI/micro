
/* USER CODE BEGIN Header */
/**
 * @file    : main.c
 * @brief   : Aula 21: eventos dos botões e contador de quatro LEDs.
 * @author  : Grupo B2
 * @date    : 14-Oct-2026
 * @version : 2.0
 * @note    : Adaptação da Aula 18 para a Aula 21 por Codex.
 */

/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/

/* Inclusão de arquivos ------------------------------------------------------*/
#include "main.h"

/* Inclusões privadas --------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "matrixKeyboard.h"
#include "buttonsEvents.h"
#include "gpio.h"
#include "tim.h"
#include "usart.h"
/* USER CODE END Includes */

/* Tipos privados ------------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Definições privadas -------------------------------------------------------*/
/* USER CODE BEGIN PD */

// Modos 1 e 2: testes da Aula 18. Modo 21: botões da placa externa.
#define MODO_TESTE_ATIVIDADE 21

/* USER CODE END PD */

/* Macros privadas -----------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Variáveis privadas --------------------------------------------------------*/
/* USER CODE BEGIN PV */
static volatile uint8_t ucMainCounter = 0U;
// Permitem acompanhar os quatro eventos de cada botão pelo debugger.
static volatile uint32_t ulButtonsPressed[BUTTON_TOTAL];
static volatile uint32_t ulButtonsReleased[BUTTON_TOTAL];
static volatile uint32_t ulButtons500ms[BUTTON_TOTAL];
static volatile uint32_t ulButtons3s[BUTTON_TOTAL];

#if (MODO_TESTE_ATIVIDADE == 2)
static uint8_t u8Contador4Bits = 0;
#endif

/* USER CODE END PV */

/* Protótipos das funções privadas -------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/**
 * @brief Mostra o valor do contador nos quatro LEDs da placa externa.
 * @param u8Valor Valor exibido em PA4, PB14, PA12, PB5.
 */
void vAtualizarLedsBinario(uint8_t u8Valor);
/* USER CODE END PFP */

/* Código do usuário ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief Configura os periféricos e inicia as bibliotecas.
 * @return Não retorna durante o funcionamento normal.
 */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* Configuração do microcontrolador ---------------------------------------*/

  // Reinicia os periféricos e inicializa a Flash e o SysTick
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  // Configura o clock do sistema
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  // Inicializa todos os periféricos configurados
  MX_GPIO_Init();
  MX_LPUART1_UART_Init();
  MX_TIM6_Init();
  MX_TIM7_Init();
  MX_TIM16_Init();

  /* USER CODE BEGIN 2 */

  ucMainCounter = 0U;
  vAtualizarLedsBinario(ucMainCounter);
  // TIM6 lê o teclado; TIM7 e TIM16 cuidam dos botões.
  vMatrixKeyboardInit(&htim6);
  vButtonsEventsInit(&htim7, &htim16);

  /* USER CODE END 2 */

  // Laço principal
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    // Atividade 1

#if (MODO_TESTE_ATIVIDADE == 1)

    // Obtém o ponteiro para ler o estado atual das teclas
    teclado *teclas = pMatrixKeyboardGetKeys();

    if (teclas->b0 == 1)      vAtualizarLedsBinario(16);
    else if (teclas->b1 == 1) vAtualizarLedsBinario(1);
    else if (teclas->b2 == 1) vAtualizarLedsBinario(2);
    else if (teclas->b3 == 1) vAtualizarLedsBinario(3);
    else if (teclas->b4 == 1) vAtualizarLedsBinario(4);
    else if (teclas->b5 == 1) vAtualizarLedsBinario(5);
    else if (teclas->b6 == 1) vAtualizarLedsBinario(6);
    else if (teclas->b7 == 1) vAtualizarLedsBinario(7);
    else if (teclas->b8 == 1) vAtualizarLedsBinario(8);
    else if (teclas->b9 == 1) vAtualizarLedsBinario(9);
    else if (teclas->ba == 1) vAtualizarLedsBinario(10);
    else if (teclas->bb == 1) vAtualizarLedsBinario(11);
    else if (teclas->bc == 1) vAtualizarLedsBinario(12);
    else if (teclas->bd == 1) vAtualizarLedsBinario(13);
    else if (teclas->bEstrela == 1)
    {
      vAtualizarLedsBinario(14);
    }
    else if (teclas->bHash == 1)
    {
      vAtualizarLedsBinario(15);
    }
    else
    {
      // Se nenhum botão estiver pressionado, apaga todos os LEDs
      vAtualizarLedsBinario(0);
    }

#endif

    HAL_Delay(50);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/** @brief Configura o clock de 170 MHz usado pelo programa e pelos timers. */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  // Configura a tensão de saída do regulador interno
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  // Inicializa os osciladores conforme os parâmetros definidos
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  // Inicializa os clocks da CPU e dos barramentos AHB e APB
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}




/* USER CODE BEGIN 4 */

/**
 * @brief Encaminha a borda do botão para a biblioteca iniciar o debounce.
 * @param GPIO_Pin Pino informado pela HAL.
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  vButtonsEventsExtiCallback(GPIO_Pin);
}


/**
 * @brief Chama a rotina da biblioteca que usa o timer recebido.
 * @param htim Ponteiro para o timer que gerou a interrupção.
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim == pTimerMatrixKeyboard)
  {
    vMatrixKeyboardPeriodElapsedCallback();
  }
  else if (htim == pTimerButtonsEventsDebouncing)
  {
    vButtonsEventsDebouncingPeriodElapsedCallback();
  }
  else if (htim == pTimerButtonsEventsLongPress)
  {
    vButtonsEventsLongPressPeriodElapsedCallback();
  }
}

/**
 * @brief Mostra o contador em binário nos LEDs de valor 8, 4, 2 e 1.
 * @param u8Valor Valor que será mostrado nos LEDs.
 * @note PA5 é usado só no teste da Aula 18, no modo 1.
 */
void vAtualizarLedsBinario(uint8_t u8Valor)
{

#if (MODO_TESTE_ATIVIDADE == 1)

  // Quinto LED, usado apenas no teste do teclado da Aula 18.
  if ((u8Valor & 16) != 0)
  {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
  }
  else
  {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
  }

#endif

  // LED amarelo: bit 3, valor 8.
  if ((u8Valor & 8) != 0)
  {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
  }
  else
  {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
  }

  // LED vermelho: bit 2, valor 4.
  if ((u8Valor & 4) != 0)
  {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_SET);
  }
  else
  {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, GPIO_PIN_RESET);
  }

  // LED verde: bit 1, valor 2.
  if ((u8Valor & 2) != 0)
  {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_SET);
  }
  else
  {
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, GPIO_PIN_RESET);
  }

  // LED azul: bit 0, valor 1.
  if ((u8Valor & 1) != 0)
  {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
  }
  else
  {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
  }
}

/**
 * @brief Incrementa o contador do teste da Aula 18, somente no modo 2.
 * @param xButton Tecla que gerou o evento de 500 ms.
 */
void vMatrixKeyboard500msPressedCallback(enum_teclado xButton)
{
  UNUSED(xButton);
#if (MODO_TESTE_ATIVIDADE == 2)

  u8Contador4Bits++;
  if (u8Contador4Bits > 15)
  {
    u8Contador4Bits = 0;
  }

  vAtualizarLedsBinario(u8Contador4Bits);

#endif
}

/**
 * @brief Alterna o LED da Nucleo no teste da Aula 18, somente no modo 2.
 * @param xButton Tecla que gerou o evento de 3 s.
 */
void vMatrixKeyboardThreeSecPressedCallback(enum_teclado xButton)
{
  UNUSED(xButton);
#if (MODO_TESTE_ATIVIDADE == 2)

  HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);

#endif
}

/**
 * @brief Soma com Cima ou subtrai com Baixo e atualiza os LEDs.
 * @param xBt Botão que gerou o evento Pressed ou de 500 ms.
 */
static void vMainUpdateCounter(button_t xBt)
{
  // Mantém o valor entre 0 e 15, que cabem nos quatro LEDs.
  switch (xBt)
  {
    case BUTTON_CIMA:
      ucMainCounter = (ucMainCounter + 1U) & 0x0FU;
      break;
    case BUTTON_BAIXO:
      ucMainCounter = (ucMainCounter + 15U) & 0x0FU;
      break;
    case BUTTON_ESQUERDA:
    case BUTTON_DIREITA:
    case BUTTON_ENTER:
    default:
      return;
  }
  vAtualizarLedsBinario(ucMainCounter);
}

/**
 * @brief Conta a pressão do botão e faz a ação de Cima ou Baixo.
 * @param xBt Botão com pressão confirmada pelo TIM7.
 */
void vButtonsEventCallbackPressedEvent(button_t xBt)
{
  if ((unsigned int)xBt < BUTTON_TOTAL)
  {
    ulButtonsPressed[xBt]++;
    vMainUpdateCounter(xBt);
  }
}

/**
 * @brief Registra a soltura do botão sem mudar os LEDs.
 * @param xBt Botão com soltura confirmada pelo TIM7.
 */
void vButtonsEventCallbackReleasedEvent(button_t xBt)
{
  if ((unsigned int)xBt < BUTTON_TOTAL)
  {
    ulButtonsReleased[xBt]++;
  }
}

/**
 * @brief Repete a ação de Cima ou Baixo a cada 500 ms.
 * @param xBt Botão que continua pressionado.
 */
void vButtonsEventCallback500msPressedEvent(button_t xBt)
{
  if ((unsigned int)xBt < BUTTON_TOTAL)
  {
    ulButtons500ms[xBt]++;
    vMainUpdateCounter(xBt);
  }
}

/**
 * @brief Zera o contador se Enter completar 3 s de pressão.
 * @param xBt Botão que completou 3 s pressionado.
 */
void vButtonsEventCallback3sPressedEvent(button_t xBt)
{
  if ((unsigned int)xBt < BUTTON_TOTAL)
  {
    ulButtons3s[xBt]++;
    if (xBt == BUTTON_ENTER)
    {
      ucMainCounter = 0U;
      vAtualizarLedsBinario(ucMainCounter);
    }
  }
}

/* USER CODE END 4 */

/** @brief Para o programa quando alguma configuração falha. */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */

  // Desabilita as interrupções e permanece nesta função
  __disable_irq();

  while (1)
  {
  }

  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT

/**
 * @brief Indica onde uma verificação da HAL falhou.
 * @param file Arquivo em que a verificação foi feita.
 * @param line Linha do arquivo em que a verificação falhou.
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */

  // Aqui pode ser implementada uma mensagem com o arquivo
  // e a linha em que ocorreu a falha de verificação

  /* USER CODE END 6 */
}

#endif /* USE_FULL_ASSERT */
