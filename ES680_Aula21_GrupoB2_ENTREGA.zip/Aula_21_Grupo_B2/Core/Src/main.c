/* USER CODE BEGIN Header */
/**
 * @file main.c
 * @brief Contador de quatro LEDs controlado pelos botões da Aula 21.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
/* USER CODE END Header */
#include "main.h"
#include "gpio.h"
#include "tim.h"

/* USER CODE BEGIN Includes */
#include "buttonsEvents.h"
/* USER CODE END Includes */

/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* USER CODE BEGIN PV */
static uint8_t ucContador;
/* USER CODE END PV */

void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
static void vMainAtualizarLeds(void);
static void vMainAtualizarContador(button_t xBt);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
 * @brief Configura os periféricos e inicia a biblioteca dos botões.
 * @return Não retorna durante o funcionamento normal.
 */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */
  MX_GPIO_Init();
  MX_TIM7_Init();
  MX_TIM16_Init();

  /* USER CODE BEGIN 2 */
  ucContador = 0U;
  vMainAtualizarLeds();
  vButtonsEventsInit(&htim7, &htim16);
  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
    // As ações dos botões são chamadas pelas interrupções.
  }
  /* USER CODE END 3 */
}

/** @brief Configura o clock de 170 MHz usado pelos timers. */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  // Configura a tensão de saída do regulador interno
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  // Inicializa os osciladores conforme os parâmetros definidos
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  // Inicializa os clocks da CPU e dos barramentos AHB e APB
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/**
 * @brief Encaminha a borda do botão para a biblioteca iniciar o debounce.
 * @param GPIO_Pin Pino informado pela HAL.
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  vButtonsEventsExtiCallback(GPIO_Pin);
}

/**
 * @brief Encaminha a interrupção para a rotina que usa o timer recebido.
 * @param htim Timer que gerou a interrupção.
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  if (htim == pTimerButtonsEventsDebouncing)
  {
    vButtonsEventsDebouncingPeriodElapsedCallback();
  }
  else if (htim == pTimerButtonsEventsLongPress)
  {
    vButtonsEventsLongPressPeriodElapsedCallback();
  }
}

/** @brief Mostra o contador em binário nos quatro LEDs da placa. */
static void vMainAtualizarLeds(void)
{
  HAL_GPIO_WritePin(LED_AMARELO_GPIO_Port, LED_AMARELO_Pin,
                   (ucContador & 8U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(LED_VERMELHO_GPIO_Port, LED_VERMELHO_Pin,
                   (ucContador & 4U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(LED_VERDE_GPIO_Port, LED_VERDE_Pin,
                   (ucContador & 2U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
  HAL_GPIO_WritePin(LED_AZUL_GPIO_Port, LED_AZUL_Pin,
                   (ucContador & 1U) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/**
 * @brief Soma com Cima ou subtrai com Baixo e atualiza os LEDs.
 * @param xBt Botão que gerou o evento Pressed ou de 500 ms.
 */
static void vMainAtualizarContador(button_t xBt)
{
  // O valor fica entre 0 e 15, que cabem nos quatro LEDs.
  if (xBt == BUTTON_CIMA)
  {
    ucContador = (ucContador + 1U) & 0x0FU;
  }
  else if (xBt == BUTTON_BAIXO)
  {
    ucContador = (ucContador + 15U) & 0x0FU;
  }
  else
  {
    return;
  }
  vMainAtualizarLeds();
}

/**
 * @brief Faz a ação de Cima ou Baixo quando a pressão é confirmada.
 * @param xBt Botão que foi pressionado.
 */
void vButtonsEventCallbackPressedEvent(button_t xBt)
{
  vMainAtualizarContador(xBt);
}

/**
 * @brief Recebe a soltura, sem alterar o contador.
 * @param xBt Botão que foi solto.
 */
void vButtonsEventCallbackReleasedEvent(button_t xBt)
{
  UNUSED(xBt);
}

/**
 * @brief Repete a ação de Cima ou Baixo a cada 500 ms.
 * @param xBt Botão que continua pressionado.
 */
void vButtonsEventCallback500msPressedEvent(button_t xBt)
{
  vMainAtualizarContador(xBt);
}

/**
 * @brief Zera o contador se Enter completar 3 s de pressão.
 * @param xBt Botão que completou 3 s pressionado.
 */
void vButtonsEventCallback3sPressedEvent(button_t xBt)
{
  if (xBt == BUTTON_ENTER)
  {
    ucContador = 0U;
    vMainAtualizarLeds();
  }
}
/* USER CODE END 4 */

/** @brief Para o programa quando alguma configuração falha. */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
 * @brief Recebe a indicação de uma verificação da HAL que falhou.
 * @param file Arquivo da verificação.
 * @param line Linha da verificação.
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  UNUSED(file);
  UNUSED(line);
  /* USER CODE END 6 */
}
#endif
