/**
 * @file gpio.c
 * @brief Configuração dos botões, LEDs e GPIOs do teclado.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
#include "gpio.h"

/** @brief Configura os LEDs, as linhas e colunas do teclado e os EXTI. */
void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  // O contador começa em zero, com os quatro LEDs apagados.
  HAL_GPIO_WritePin(GPIOA, LED_AMARELO_Pin | LED_VERDE_Pin | GPIO_PIN_10,
                   GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOB, LED_VERMELHO_Pin | LED_AZUL_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9,
                   GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = LED_AMARELO_Pin | LED_VERDE_Pin | GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = LED_VERMELHO_Pin | LED_AZUL_Pin;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // Colunas e linhas do teclado, conforme a biblioteca original.
  GPIO_InitStruct.Pin = GPIO_PIN_7 | GPIO_PIN_8 | GPIO_PIN_9;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = GPIO_PIN_11 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  // Nível alto ao pressionar e baixo ao soltar; ambas as bordas geram EXTI.
  GPIO_InitStruct.Pin = BT_CIMA_Pin | BT_BAIXO_Pin |
                        BT_ESQUERDA_Pin | BT_DIREITA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = BT_ENTER_Pin;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(EXTI0_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(EXTI0_IRQn);
  HAL_NVIC_SetPriority(EXTI1_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);
  HAL_NVIC_SetPriority(EXTI2_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);
  HAL_NVIC_SetPriority(EXTI3_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);
  HAL_NVIC_SetPriority(EXTI4_IRQn, 7, 0);
  HAL_NVIC_EnableIRQ(EXTI4_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}
