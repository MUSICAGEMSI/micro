/**
 * @file tim.h
 * @brief Timers usados pelos botões da Aula 21.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
#ifndef TIM_H
#define TIM_H

#include "main.h"

extern TIM_HandleTypeDef htim7;
extern TIM_HandleTypeDef htim16;

/** @brief Configura o TIM7 para os 10 ms de debounce. */
void MX_TIM7_Init(void);

/** @brief Configura o TIM16 para medir o tempo dos botões pressionados. */
void MX_TIM16_Init(void);

#endif // TIM_H
