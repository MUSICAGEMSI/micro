
/**
 * @file    : matrixKeyboard.h
 * @brief   : Declarações para leitura do teclado matricial 4x4.
 * @author  : Grupo B2
 * @date    : 14-Oct-2026
 * @version : 2.0
 * @note    : Comentários revisados por Codex em 03-Nov-2026.
 */


#ifndef MATRIXKEYBOARD_H
#define MATRIXKEYBOARD_H

#include "main.h"

typedef enum {
  KEY_VAZIA = 0,
  KEY_0, KEY_1, KEY_2, KEY_3,
  KEY_4, KEY_5, KEY_6, KEY_7,
  KEY_8, KEY_9, KEY_A, KEY_B,
  KEY_C, KEY_D, KEY_ESTRELA, KEY_HASH,
  KEY_TOTAL_NUM
} enum_teclado;

typedef struct teclado {
  char b1;
  char b2;
  char b3;
  char b4;
  char b5;
  char b6;
  char b7;
  char b8;
  char b9;
  char bHash;
  char bEstrela;
  char b0;
  char ba;
  char bb;
  char bc;
  char bd;
} teclado;

typedef struct {
  uint16_t u16TempoPress500ms; // Recomeça a cada evento de 500 ms.
  uint16_t u16TempoPress3s;    // Tempo usado para detectar os 3 s.
  uint8_t u8Evento3sDisparado; // Evita repetir o evento antes da soltura.
} st_tecla_timer;

/** @brief Permite identificar o TIM6 na callback de timers do main.c. */
extern TIM_HandleTypeDef *pTimerMatrixKeyboard;

/** @brief Recebe a interrupção do TIM6 e chama a leitura do teclado. */
void vMatrixKeyboardPeriodElapsedCallback(void);

/**
 * @brief Inicia o timer usado para ler o teclado.
 * @param htim Ponteiro para o TIM6, configurado para 10 ms.
 */
void vMatrixKeyboardInit(TIM_HandleTypeDef *htim);

/**
 * @brief Permite consultar o estado de cada tecla.
 * @return Ponteiro para a estrutura do teclado.
 */
teclado* pMatrixKeyboardGetKeys(void);

/** @brief Lê uma coluna do teclado e atualiza os tempos de pressão. */
void vMatrixKeyboardCallback(void);

/**
 * @brief Evento repetido a cada 500 ms enquanto a tecla estiver pressionada.
 * @param xButton Tecla que continua pressionada.
 */
void vMatrixKeyboard500msPressedCallback(enum_teclado xButton);

/**
 * @brief Evento chamado uma vez ao completar 3 s de pressão.
 * @param xButton Tecla que continua pressionada.
 */
void vMatrixKeyboardThreeSecPressedCallback(enum_teclado xButton);

#endif // MATRIXKEYBOARD_H
