
/**
 * @file    : matrixKeyboard.h
 * @brief   : Declarações para leitura do teclado matricial 4x4.
 * @author  : Grupo B2
 * @date    : 14-Oct-2026
 * @version : 1.1
 */


#ifndef MATRIXKEYBOARD_H
#define MATRIXKEYBOARD_H

#include "main.h"

typedef enum {
  KEY_VAZIA = 0,
  KEY_0, KEY_1, KEY_2, KEY_3,
  KEY_4, KEY_5, KEY_6, KEY_7,
  KEY_8, KEY_9, KEY_A, KEY_B,
  KEY_C, KEY_D, KEY_ESTRELA, KEY_HASH,
  KEY_TOTAL_NUM
} enum_teclado;

typedef struct teclado {
  char b1;
  char b2;
  char b3;
  char b4;
  char b5;
  char b6;
  char b7;
  char b8;
  char b9;
  char bHash;
  char bEstrela;
  char b0;
  char ba;
  char bb;
  char bc;
  char bd;
} teclado;

typedef struct {
  uint16_t u16TempoPress500ms; // Conta até 500 ms repetidamente
  uint16_t u16TempoPress3s;    // Conta até 3000 ms
  uint8_t u8Evento3sDisparado; // Flag do evento de 3 s
} st_tecla_timer;

/** @brief Timer usado pelo teclado na callback compartilhada do main. */
extern TIM_HandleTypeDef *pTimerMatrixKeyboard;

/** @brief Recebe o fim do período do TIM6 e chama a leitura original. */
void vMatrixKeyboardPeriodElapsedCallback(void);

/**
 * @brief Guarda o timer do teclado e inicia suas interrupções.
 * @param htim TIM6 configurado para 10 ms.
 */
void vMatrixKeyboardInit(TIM_HandleTypeDef *htim);

/**
 * @brief Permite consultar os estados lidos do teclado.
 * @return Ponteiro para a estrutura do teclado.
 */
teclado* pMatrixKeyboardGetKeys(void);

/** @brief Lê as linhas de uma coluna e atualiza os tempos das teclas. */
void vMatrixKeyboardCallback(void);

/**
 * @brief Evento de 500 ms de uma tecla mantida pressionada.
 * @param xButton Tecla que gerou o evento.
 */
void vMatrixKeyboard500msPressedCallback(enum_teclado xButton);

/**
 * @brief Evento de 3 s de uma tecla mantida pressionada.
 * @param xButton Tecla que gerou o evento.
 */
void vMatrixKeyboardThreeSecPressedCallback(enum_teclado xButton);

#endif // MATRIXKEYBOARD_H
