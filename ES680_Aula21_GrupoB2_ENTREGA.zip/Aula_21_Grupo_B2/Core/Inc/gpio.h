/**
 * @file gpio.h
 * @brief Função de configuração dos pinos do projeto.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 2.0
 */
#ifndef GPIO_H
#define GPIO_H

#include "main.h"


/** @brief Prepara os pinos dos LEDs, teclado e botões. */
void MX_GPIO_Init(void);

#endif // GPIO_H
