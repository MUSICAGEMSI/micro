/**
 * @file gpio.h
 * @brief Configuração dos botões e LEDs da Aula 21.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
#ifndef GPIO_H
#define GPIO_H

#include "main.h"


/** @brief Prepara os pinos dos LEDs, dos botões e do teclado. */
void MX_GPIO_Init(void);

#endif // GPIO_H
