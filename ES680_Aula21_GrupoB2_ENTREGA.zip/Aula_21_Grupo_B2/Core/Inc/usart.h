/**
 * @file usart.h
 * @brief Função de configuração da LPUART1.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 2.0
 */
#ifndef USART_H
#define USART_H

#include "main.h"

extern UART_HandleTypeDef hlpuart1;

/** @brief Configura a LPUART1 em 115200 baud. */
void MX_LPUART1_UART_Init(void);

#endif // USART_H
