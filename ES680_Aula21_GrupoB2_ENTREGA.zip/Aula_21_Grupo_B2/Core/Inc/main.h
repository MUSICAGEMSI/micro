/**
 * @file main.h
 * @brief Pinos dos cinco botões e dos quatro LEDs da Aula 21.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
#ifndef MAIN_H
#define MAIN_H

#include "stm32g4xx_hal.h"

#define BT_CIMA_Pin GPIO_PIN_1
#define BT_CIMA_GPIO_Port GPIOC
#define BT_CIMA_EXTI_IRQn EXTI1_IRQn
#define BT_BAIXO_Pin GPIO_PIN_2
#define BT_BAIXO_GPIO_Port GPIOC
#define BT_BAIXO_EXTI_IRQn EXTI2_IRQn
#define BT_ESQUERDA_Pin GPIO_PIN_3
#define BT_ESQUERDA_GPIO_Port GPIOC
#define BT_ESQUERDA_EXTI_IRQn EXTI3_IRQn
#define BT_DIREITA_Pin GPIO_PIN_4
#define BT_DIREITA_GPIO_Port GPIOC
#define BT_DIREITA_EXTI_IRQn EXTI4_IRQn
#define BT_ENTER_Pin GPIO_PIN_0
#define BT_ENTER_GPIO_Port GPIOB
#define BT_ENTER_EXTI_IRQn EXTI0_IRQn

#define LED_AMARELO_Pin GPIO_PIN_4
#define LED_AMARELO_GPIO_Port GPIOA
#define LED_VERMELHO_Pin GPIO_PIN_14
#define LED_VERMELHO_GPIO_Port GPIOB
#define LED_VERDE_Pin GPIO_PIN_12
#define LED_VERDE_GPIO_Port GPIOA
#define LED_AZUL_Pin GPIO_PIN_5
#define LED_AZUL_GPIO_Port GPIOB

/** @brief Para o programa quando alguma configuração falha. */
void Error_Handler(void);

#endif // MAIN_H
