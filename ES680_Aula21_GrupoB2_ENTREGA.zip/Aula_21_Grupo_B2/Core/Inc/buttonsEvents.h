/**
 * @file buttonsEvents.h
 * @brief Funções de leitura e eventos dos cinco botões da Aula 21.
 * @author Codex, a pedido do Grupo B2.
 * @date 03-Nov-2026
 * @version 3.0
 */
#ifndef BUTTONSEVENTS_H
#define BUTTONSEVENTS_H

#include "tim.h"

/** @brief Identifica os cinco botões da placa externa. */
typedef enum
{
  BUTTON_CIMA = 0, // PC1 / EXTI1
  BUTTON_BAIXO,    // PC2 / EXTI2
  BUTTON_ESQUERDA, // PC3 / EXTI3
  BUTTON_DIREITA,  // PC4 / EXTI4
  BUTTON_ENTER,    // PB0 / EXTI0
  BUTTON_TOTAL
} button_t;

extern TIM_HandleTypeDef *pTimerButtonsEventsDebouncing;
extern TIM_HandleTypeDef *pTimerButtonsEventsLongPress;

/**
 * @brief Prepara a leitura dos botões com os timers recebidos.
 * @param pTimDebouncer TIM7, usado para os 10 ms de debounce.
 * @param pTimPressedTime TIM16, usado para medir o tempo de pressão.
 * @note Um botão pressionado ao ligar também é confirmado pelo TIM7.
 * @note As callbacks não devem usar espera nem reiniciar esta biblioteca.
 */
void vButtonsEventsInit(TIM_HandleTypeDef *pTimDebouncer,
                       TIM_HandleTypeDef *pTimPressedTime);

/**
 * @brief Recebe da HAL o pino que mudou e inicia seu debounce.
 * @param GPIO_Pin Pino de um dos cinco botões, nas linhas EXTI0 a EXTI4.
 */
void vButtonsEventsExtiCallback(uint16_t GPIO_Pin);

/** @brief Confere o estado dos botões quando o TIM7 termina os 10 ms. */
void vButtonsEventsDebouncingPeriodElapsedCallback(void);

/** @brief Atualiza o tempo de pressão a cada interrupção de 10 ms do TIM16. */
void vButtonsEventsLongPressPeriodElapsedCallback(void);

/**
 * @brief Chamado quando a pressão do botão é confirmada pelo debounce.
 * @param xBt Botão que foi pressionado.
 */
void vButtonsEventCallbackPressedEvent(button_t xBt);

/**
 * @brief Chamado quando a soltura do botão é confirmada pelo debounce.
 * @param xBt Botão que foi solto.
 */
void vButtonsEventCallbackReleasedEvent(button_t xBt);

/**
 * @brief Chamado a cada 500 ms enquanto o botão estiver pressionado.
 * @param xBt Botão que continua pressionado.
 */
void vButtonsEventCallback500msPressedEvent(button_t xBt);

/**
 * @brief Chamado uma vez quando o botão completa 3 s de pressão.
 * @param xBt Botão que continua pressionado.
 */
void vButtonsEventCallback3sPressedEvent(button_t xBt);

#endif // BUTTONSEVENTS_H
